import 'dotenv/config';
import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI, Type } from '@google/genai';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(express.json({ limit: '1mb' }));

const PORT = Number(process.env.PORT) || 3000;

function getGeminiClient() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error('GEMINI_API_KEY is not configured in environment secrets.');
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

async function generateWithFallback(
  ai: GoogleGenAI,
  params: Omit<Parameters<typeof ai.models.generateContent>[0], 'model'>
) {
  const primaryModel = 'gemini-2.5-flash';
  const fallbackModel = 'gemini-4-hydrogen';

  try {
    return await ai.models.generateContent({
      model: primaryModel,
      ...params,
    });
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    if (msg.includes('404') || msg.includes('NOT_FOUND') || msg.toLowerCase().includes('not found')) {
      return await ai.models.generateContent({
        model: fallbackModel,
        ...params,
      });
    }
    throw err;
  }
}

interface PolicyContextItem {
  id: string;
  agency: string;
  sector: string;
  docketNumber: string;
  title: string;
  publishedDate: string;
  effectiveDate: string;
  severity: string;
  aiSummary: string;
  amendmentClause: string;
  supersededRule: string;
  newRule: string;
  relevanceScore?: number;
  personaImpact?: string;
}

app.post('/api/analyst/ask', async (req, res) => {
  try {
    const {
      question,
      personaLabel,
      personaMandate,
      activePolicies,
      history,
    }: {
      question: string;
      personaLabel: string;
      personaMandate: string;
      activePolicies: PolicyContextItem[];
      history?: { role: 'user' | 'assistant'; text: string }[];
    } = req.body || {};

    if (!question || typeof question !== 'string' || !question.trim()) {
      res.status(400).json({ error: 'Please provide a regulatory question.' });
      return;
    }

    const ai = getGeminiClient();

    const policyContextText = (activePolicies || [])
      .slice(0, 12)
      .map(
        (p) =>
          `[${p.agency} | ${p.docketNumber} | ${p.sector} | Relevance: ${p.relevanceScore ?? 'N/A'}% | Effective: ${p.effectiveDate}]\nTitle: ${p.title}\nSummary: ${p.aiSummary}\nClause (${p.amendmentClause}) — Superseded: ${p.supersededRule} -> New Rule: ${p.newRule}\nPersona Impact: ${p.personaImpact ?? 'N/A'}`
      )
      .join('\n\n---\n\n');

    const historyText = (history || [])
      .slice(-6)
      .map((m) => `${m.role === 'user' ? 'Executive' : 'wolfreg Analyst'}: ${m.text}`)
      .join('\n');

    const systemInstruction = `You are wolfreg AI Analyst, a senior Indian renewable energy & climate policy strategist advising B2B executives, infrastructure funds, IPPs, CBG operators, and climate tech founders.
Active Executive Persona: ${personaLabel} (${personaMandate}).
Ground your answer strictly in the provided active Indian regulatory corpus (MNRE, CERC, SECI, IREDA, MoP, CEA, PIB, e-Gazette).
Deliver crisp, Bloomberg-terminal-grade analysis:
1. Direct regulatory takeaway tailored to the active persona (2-3 sentences).
2. Quantified financial, tariff, or compliance impact referencing exact docket numbers, deadlines, bps/₹ figures, or percentage thresholds from the corpus.
3. Recommended concrete next action (1-2 bullet points).
Keep responses under 260 words, authoritative, structured, and free of filler.`;

    const prompt = `Active Policy Corpus:\n${policyContextText}\n\n${
      historyText ? `Recent Conversation:\n${historyText}\n\n` : ''
    }Executive Question: ${question.trim()}`;

    const response = await generateWithFallback(ai, {
      contents: prompt,
      config: {
        systemInstruction,
      },
    });

    const answer = response.text?.trim() || 'No synthesis returned from the regulatory model.';
    const citedDockets = (activePolicies || [])
      .filter((p) => answer.includes(p.docketNumber) || answer.includes(p.agency))
      .map((p) => ({ id: p.id, agency: p.agency, docketNumber: p.docketNumber, title: p.title }));

    res.json({
      answer,
      citedDockets,
    });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Failed to query wolfreg AI Analyst.';
    console.error('Analyst error:', message);
    res.status(500).json({ error: message });
  }
});

app.post('/api/analyst/memo', async (req, res) => {
  try {
    const {
      personaLabel,
      personaMandate,
      focusTopic,
      horizon,
      selectedPolicies,
    }: {
      personaLabel: string;
      personaMandate: string;
      focusTopic: string;
      horizon: string;
      selectedPolicies: PolicyContextItem[];
    } = req.body || {};

    if (!selectedPolicies || !Array.isArray(selectedPolicies) || selectedPolicies.length === 0) {
      res.status(400).json({ error: 'At least one policy document is required to generate a boardroom memo.' });
      return;
    }

    const ai = getGeminiClient();

    const policyBlock = selectedPolicies
      .slice(0, 8)
      .map(
        (p) =>
          `• ${p.agency} (${p.docketNumber}) — ${p.title} [Effective: ${p.effectiveDate}, Relevance: ${p.relevanceScore ?? 85}%]\n  Summary: ${p.aiSummary}\n  Amendment (${p.amendmentClause}): "${p.supersededRule}" -> "${p.newRule}"`
      )
      .join('\n\n');

    const response = await generateWithFallback(ai, {
      contents: `Generate an executive boardroom memorandum for a ${personaLabel} (${personaMandate}).
Strategic Focus: ${focusTopic}
Planning Horizon: ${horizon}

Regulatory Inputs:
${policyBlock}`,
      config: {
        systemInstruction:
          'You are an institutional clean-energy investment & regulatory partner preparing an Indian market Boardroom Memorandum. Be concrete, cite docket numbers, INR/tariff/bps metrics, and compliance cutoffs.',
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING, description: 'Formal boardroom memo headline' },
            executiveThesis: {
              type: Type.STRING,
              description: 'Concise 3-4 sentence strategic thesis synthesizing the regulatory shift',
            },
            capitalAllocation: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: '3 concrete capital allocation or IRR/capex implications',
            },
            complianceRisks: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  agency: { type: Type.STRING },
                  risk: { type: Type.STRING },
                  mitigation: { type: Type.STRING },
                },
                required: ['agency', 'risk', 'mitigation'],
              },
              description: 'Top 3 regulatory compliance risks and mitigations',
            },
            strategicActions: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: '3 immediate 90-day executive actions',
            },
            referencedDockets: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: 'List of cited docket numbers',
            },
          },
          required: [
            'title',
            'executiveThesis',
            'capitalAllocation',
            'complianceRisks',
            'strategicActions',
            'referencedDockets',
          ],
        },
      },
    });

    const rawText = response.text?.trim();
    if (!rawText) {
      throw new Error('Empty memo response returned from Gemini.');
    }

    const memo = JSON.parse(rawText);
    res.json({ memo });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Failed to generate Boardroom Memo.';
    console.error('Memo generation error:', message);
    res.status(500).json({ error: message });
  }
});

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`wolfreg server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start wolfreg server:', err);
  process.exit(1);
});
