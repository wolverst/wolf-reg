# Wolf Insights Security Specification

## 1. Data Invariants
1. **Published Policy Integrity**: All documents in `/policies/{policyId}` must have valid IDs (`^[a-zA-Z0-9_\-]+$`), valid agency enums (`MNRE`, `CERC`, `SECI`, `IREDA`, `MoP`, `CEA`, `PIB`, `e-Gazette`), bounded string sizes, and server-verified `createdAt == request.time`. Only verified administrators (`isAdmin()`) may create, update, or delete policies.
2. **Private Alert Rule Ownership & PII Protection**: `/alertRules/{ruleId}` stores personal phone numbers / emails (`destination`). Only the authenticated verified owner (`resource.data.ownerId == request.auth.uid`) may read, list, update, or delete their alert rules.
3. **Private Boardroom Memo Ownership**: `/boardroomMemos/{memoId}` belongs strictly to the authenticated verified user (`ownerId == request.auth.uid`). `ownerId` and `createdAt` are immutable once created.
4. **Admin Bootstrapping**: Admin privileges require `request.auth.token.email_verified == true` and either presence in `/admins/{uid}` or matching the verified runtime admin email (`projectwolverst@gmail.com`).

## 2. Adversarial "Dirty Dozen" Rejection Vectors
1. **Shadow Field Injection on Policy**: Sending `isVerified: true` or extra undocumented keys to `/policies/{id}` -> rejected by `hasOnly(...)`.
2. **Unverified Email Admin Spoof**: Authenticated user with `email: "projectwolverst@gmail.com"` and `email_verified: false` attempting policy write -> rejected by `email_verified == true`.
3. **Cross-Tenant Alert Rule Read (`get`)**: User B reading User A's `/alertRules/{ruleId}` containing WhatsApp phone/email PII -> rejected by `resource.data.ownerId == request.auth.uid`.
4. **Unscoped Alert Rule Scraping (`list`)**: Authenticated user listing `/alertRules` without `where('ownerId', '==', uid)` -> rejected by rule-enforced `resource.data.ownerId == request.auth.uid`.
5. **Owner Spoofing on Create**: User A creating `/alertRules/{id}` with `ownerId: "user-b"` -> rejected by `incoming().ownerId == request.auth.uid`.
6. **Immutable Owner Mutation on Update**: User A updating `ownerId` or `createdAt` on `/alertRules/{id}` -> rejected by immutability check & `affectedKeys().hasOnly(...)`.
7. **Client Timestamp Forgery**: Creating a policy or alertRule with a backdated `createdAt` instead of `request.time` -> rejected by `incoming().createdAt == request.time`.
8. **Document ID Poisoning**: Attempting to write `/policies/../../etc` or a 1.5KB document ID -> rejected by `isValidId()`.
9. **Resource Exhaustion / Payload Bomb**: Writing a 2MB `aiSummary` or `contentMarkdown` string -> rejected by `.size() <= maxLength`.
10. **Invalid Agency/Sector Enum**: Writing `agency: "UNKNOWN"` to `/policies/{id}` -> rejected by enum allowlist.
11. **Out-of-Bounds Threshold**: Setting `minRelevanceScore: 999` or `-5` on `/alertRules/{id}` -> rejected by `int` range check `>= 50 && <= 100`.
12. **Unauthenticated Write**: Anonymous/unauthenticated caller writing to any collection -> rejected by global deny and `isSignedIn()`.
