export type Agency =
  | 'MNRE'
  | 'CERC'
  | 'SECI'
  | 'IREDA'
  | 'MoP'
  | 'CEA'
  | 'PIB'
  | 'e-Gazette';

export type Sector = 'Solar' | 'Biogas & CBG' | 'Green Hydrogen' | 'Grid & BESS';

export type Severity = 'Critical' | 'Material' | 'Procedural';

export type PersonaId = 'investor' | 'startup' | 'biogas' | 'climatetech';

export type WorkspaceView = 'feed' | 'diffs' | 'portals' | 'memo';

export interface PersonaProfile {
  relevanceScore: number;
  impactSummary: string;
}

export interface PersonaConfig {
  id: PersonaId;
  label: string;
  shortLabel: string;
  mandate: string;
  focusMetrics: string;
}

export interface PolicyDocument {
  id: string;
  docketNumber: string;
  agency: Agency;
  sector: Sector;
  title: string;
  publishedDate: string;
  effectiveDate: string;
  severity: Severity;
  aiSummary: string;
  amendmentClause: string;
  supersededRule: string;
  newRule: string;
  sourceUrl: string;
  isPublished: boolean;
  personaProfiles: Record<PersonaId, PersonaProfile>;
}

export interface PortalStatus {
  agency: Agency;
  fullName: string;
  domain: string;
  cadence: string;
  trackedDocs: number;
  lastSyncedMinutesAgo: number;
  status: 'Synced' | 'Syncing' | 'Rate Limited';
  latestDocket: string;
}

export interface AlertRule {
  id: string;
  channel: 'WhatsApp' | 'Email' | 'Both';
  destination: string;
  minRelevanceScore: number;
  personaId: PersonaId;
  cadence: 'Instant Critical' | 'Daily 08:00 IST' | 'Weekly Board Brief';
  sectors: Sector[];
  enabled: boolean;
  createdAt?: string;
}

export interface BoardroomMemoResult {
  title: string;
  executiveThesis: string;
  capitalAllocation: string[];
  complianceRisks: {
    agency: string;
    risk: string;
    mitigation: string;
  }[];
  strategicActions: string[];
  referencedDockets: string[];
}

export interface AnalystMessage {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  citedDockets?: {
    id: string;
    agency: string;
    docketNumber: string;
    title: string;
  }[];
  timestamp: string;
}
