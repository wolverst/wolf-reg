import React from 'react';
import { CheckCircle2, Database, ExternalLink, RefreshCw } from 'lucide-react';
import { Agency, PortalStatus } from '../types';

interface PortalsHubViewProps {
  portals: PortalStatus[];
  syncingAgency: Agency | 'ALL' | null;
  dataSource: 'firestore' | 'fallback';
  isAdminUser: boolean;
  isSeeding: boolean;
  onSyncPortal: (agency: Agency) => void;
  onSyncAll: () => void;
  onFilterByAgency: (agency: Agency) => void;
  onSeedFirestore: () => void;
}

export const PortalsHubView: React.FC<PortalsHubViewProps> = ({
  portals,
  syncingAgency,
  dataSource,
  isAdminUser,
  isSeeding,
  onSyncPortal,
  onSyncAll,
  onFilterByAgency,
  onSeedFirestore,
}) => {
  return (
    <section className="space-y-5">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div>
          <h2 className="text-xl font-semibold text-slate-900 dark:text-white">
            Monitored Government Portals Hub
          </h2>
          <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
            Automated docket surveillance across India’s 8 core power, clean-fuel, and statutory gazette authorities.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          {isAdminUser && (
            <button
              type="button"
              disabled={isSeeding}
              onClick={onSeedFirestore}
              className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-obsidian-900 text-slate-800 dark:text-slate-100 hover:bg-slate-50 dark:hover:bg-obsidian-850 disabled:opacity-50 transition-colors cursor-pointer"
            >
              <Database className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
              {isSeeding ? 'Syncing to Firestore...' : 'Publish Benchmark Policies to Firestore'}
            </button>
          )}

          <button
            type="button"
            disabled={syncingAgency === 'ALL'}
            onClick={onSyncAll}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium rounded-lg bg-slate-900 text-white dark:bg-emerald-500 dark:text-obsidian-950 hover:bg-slate-800 dark:hover:bg-emerald-400 disabled:opacity-60 transition-colors cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${syncingAgency === 'ALL' ? 'animate-spin' : ''}`} />
            {syncingAgency === 'ALL' ? 'Crawling 8 Portals...' : 'Sync All Portals'}
          </button>
        </div>
      </div>

      {/* Firestore Source Summary Strip */}
      <div className="bg-white dark:bg-obsidian-900 border border-slate-200 dark:border-slate-800 rounded-xl px-5 py-3.5 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2 text-slate-700 dark:text-slate-300">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-500 shrink-0" />
          <span>
            Active Corpus Store:{' '}
            <strong className="font-semibold text-slate-900 dark:text-white">
              {dataSource === 'firestore'
                ? 'Live Cloud Firestore (policies collection)'
                : 'Verified Local Benchmark Cache (Firestore collection unseeded or offline)'}
            </strong>
          </span>
        </div>
        <span className="font-mono tabular-nums text-slate-500 dark:text-slate-400">
          Total Indexed Circulars: {portals.reduce((acc, p) => acc + p.trackedDocs, 0)}
        </span>
      </div>

      {/* 8-Portal Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
        {portals.map((portal) => {
          const isSyncing = syncingAgency === portal.agency || syncingAgency === 'ALL';
          return (
            <div
              key={portal.agency}
              className="bg-white dark:bg-obsidian-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 flex flex-col justify-between gap-4"
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-1.5">
                  <span className="text-base font-bold text-slate-900 dark:text-white">
                    {portal.agency}
                  </span>
                  <span className="text-xs font-medium text-emerald-700 dark:text-emerald-400">
                    {isSyncing ? 'Syncing' : portal.status}
                  </span>
                </div>

                <p className="text-xs text-slate-600 dark:text-slate-300 leading-snug mb-3">
                  {portal.fullName}
                </p>

                <dl className="space-y-1.5 text-xs border-t border-slate-100 dark:border-slate-800 pt-3">
                  <div className="flex items-center justify-between gap-2">
                    <dt className="text-slate-500 dark:text-slate-400">Endpoint</dt>
                    <dd className="font-mono text-slate-800 dark:text-slate-200">
                      <a
                        href={`https://${portal.domain}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1 hover:underline"
                      >
                        {portal.domain}
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    </dd>
                  </div>
                  <div className="flex items-center justify-between gap-2">
                    <dt className="text-slate-500 dark:text-slate-400">Crawl Cadence</dt>
                    <dd className="font-mono text-slate-800 dark:text-slate-200">{portal.cadence}</dd>
                  </div>
                  <div className="flex items-center justify-between gap-2">
                    <dt className="text-slate-500 dark:text-slate-400">Indexed Docs</dt>
                    <dd className="font-mono tabular-nums text-slate-800 dark:text-slate-200">
                      {portal.trackedDocs}
                    </dd>
                  </div>
                  <div className="flex items-center justify-between gap-2">
                    <dt className="text-slate-500 dark:text-slate-400">Last Sync</dt>
                    <dd className="font-mono tabular-nums text-slate-800 dark:text-slate-200">
                      {portal.lastSyncedMinutesAgo === 0
                        ? 'Just now'
                        : `${portal.lastSyncedMinutesAgo}m ago`}
                    </dd>
                  </div>
                </dl>

                <div className="mt-3 pt-2.5 border-t border-slate-100 dark:border-slate-800">
                  <div className="text-[11px] text-slate-500 dark:text-slate-400 mb-0.5">
                    Latest Tracked Docket
                  </div>
                  <div
                    className="text-xs font-mono text-slate-800 dark:text-slate-200 truncate"
                    title={portal.latestDocket}
                  >
                    {portal.latestDocket}
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => onFilterByAgency(portal.agency)}
                  className="flex-1 px-3 py-1.5 text-xs font-medium rounded-md border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-obsidian-850 transition-colors cursor-pointer"
                >
                  View Policies
                </button>
                <button
                  type="button"
                  disabled={isSyncing}
                  onClick={() => onSyncPortal(portal.agency)}
                  aria-label={`Sync ${portal.agency}`}
                  className="px-2.5 py-1.5 text-xs font-medium rounded-md border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-obsidian-850 disabled:opacity-50 transition-colors cursor-pointer"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
};
