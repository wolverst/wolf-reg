import React, { useState } from 'react';
import { Bell, Trash2, X } from 'lucide-react';
import { AlertRule, PersonaConfig, PolicyDocument, Sector } from '../types';

interface SmartAlertModalProps {
  isOpen: boolean;
  onClose: () => void;
  persona: PersonaConfig;
  policies: PolicyDocument[];
  rules: AlertRule[];
  isSignedIn: boolean;
  onSaveRule: (rule: AlertRule) => Promise<void>;
  onDeleteRule: (ruleId: string) => Promise<void>;
  onToggleRule: (rule: AlertRule) => Promise<void>;
}

const ALL_SECTORS: Sector[] = ['Solar', 'Biogas & CBG', 'Green Hydrogen', 'Grid & BESS'];

export const SmartAlertModal: React.FC<SmartAlertModalProps> = ({
  isOpen,
  onClose,
  persona,
  policies,
  rules,
  isSignedIn,
  onSaveRule,
  onDeleteRule,
  onToggleRule,
}) => {
  const [channel, setChannel] = useState<'WhatsApp' | 'Email' | 'Both'>('WhatsApp');
  const [destination, setDestination] = useState('+91 98201 44510');
  const [minScore, setMinScore] = useState(85);
  const [cadence, setCadence] = useState<AlertRule['cadence']>('Instant Critical');
  const [selectedSectors, setSelectedSectors] = useState<Sector[]>(ALL_SECTORS);
  const [isSaving, setIsSaving] = useState(false);

  if (!isOpen) return null;

  const matchingCount = policies.filter((p) => {
    const score = p.personaProfiles[persona.id]?.relevanceScore ?? 0;
    return score >= minScore && selectedSectors.includes(p.sector);
  }).length;

  function toggleSector(sector: Sector) {
    setSelectedSectors((prev) =>
      prev.includes(sector) ? prev.filter((s) => s !== sector) : [...prev, sector]
    );
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!destination.trim() || selectedSectors.length === 0) return;

    setIsSaving(true);
    try {
      const newRule: AlertRule = {
        id: `alert-${Date.now()}`,
        channel,
        destination: destination.trim(),
        minRelevanceScore: minScore,
        personaId: persona.id,
        cadence,
        sectors: selectedSectors,
        enabled: true,
      };
      await onSaveRule(newRule);
    } finally {
      setIsSaving(false);
    }
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/65 backdrop-blur-[2px]"
      role="dialog"
      aria-modal="true"
      aria-label="Configure Smart Executive Alerts"
    >
      <div className="w-full max-w-2xl bg-white dark:bg-obsidian-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
        <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-4">
          <div>
            <h2 className="text-base sm:text-lg font-semibold text-slate-900 dark:text-white">
              Executive Alert Thresholds
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              {isSignedIn
                ? 'Rules sync directly to your Cloud Firestore executive profile.'
                : 'Saved locally in browser; sign in with Google to sync across devices.'}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close modal"
            className="p-2 rounded-lg text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-obsidian-850 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="overflow-y-auto p-6 space-y-6">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  Delivery Channel
                </label>
                <div className="grid grid-cols-3 gap-1 p-1 bg-slate-100 dark:bg-obsidian-950 border border-slate-200 dark:border-slate-800 rounded-lg">
                  {(['WhatsApp', 'Email', 'Both'] as const).map((ch) => (
                    <button
                      key={ch}
                      type="button"
                      onClick={() => setChannel(ch)}
                      className={`py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                        channel === ch
                          ? 'bg-white dark:bg-obsidian-800 text-slate-900 dark:text-white shadow-xs'
                          : 'text-slate-600 dark:text-slate-400'
                      }`}
                    >
                      {ch}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label
                  htmlFor="alert-cadence"
                  className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5"
                >
                  Delivery Cadence
                </label>
                <select
                  id="alert-cadence"
                  value={cadence}
                  onChange={(e) => setCadence(e.target.value as AlertRule['cadence'])}
                  className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-obsidian-850 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white"
                >
                  <option value="Instant Critical">Instant Critical</option>
                  <option value="Daily 08:00 IST">Daily 08:00 IST</option>
                  <option value="Weekly Board Brief">Weekly Board Brief</option>
                </select>
              </div>
            </div>

            <div>
              <label
                htmlFor="alert-dest"
                className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5"
              >
                {channel === 'Email' ? 'Executive Email' : 'WhatsApp Number / Executive Email'}
              </label>
              <input
                id="alert-dest"
                type="text"
                required
                value={destination}
                onChange={(e) => setDestination(e.target.value)}
                placeholder="+91 98201 44510 or partner@fund.in"
                className="w-full px-3.5 py-2 text-sm bg-slate-50 dark:bg-obsidian-850 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/40"
              />
            </div>

            <div>
              <div className="flex items-center justify-between text-xs mb-1.5">
                <label htmlFor="alert-score" className="font-semibold text-slate-700 dark:text-slate-300">
                  Minimum Relevance Threshold ({persona.shortLabel})
                </label>
                <span className="font-mono tabular-nums font-semibold text-emerald-600 dark:text-emerald-400">
                  {minScore}%+ ({matchingCount} matching policies)
                </span>
              </div>
              <input
                id="alert-score"
                type="range"
                min={60}
                max={95}
                step={5}
                value={minScore}
                onChange={(e) => setMinScore(Number(e.target.value))}
                className="w-full accent-emerald-500 cursor-pointer"
              />
            </div>

            <div>
              <span className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
                Monitored Clean Energy Sectors
              </span>
              <div className="flex flex-wrap gap-2">
                {ALL_SECTORS.map((sec) => {
                  const active = selectedSectors.includes(sec);
                  return (
                    <button
                      key={sec}
                      type="button"
                      onClick={() => toggleSector(sec)}
                      className={`px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors cursor-pointer ${
                        active
                          ? 'bg-emerald-500/15 border-emerald-500/50 text-emerald-700 dark:text-emerald-300'
                          : 'bg-slate-50 dark:bg-obsidian-850 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
                      }`}
                    >
                      {sec}
                    </button>
                  );
                })}
              </div>
            </div>

            <button
              type="submit"
              disabled={isSaving || selectedSectors.length === 0}
              className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-semibold rounded-lg bg-slate-900 text-white dark:bg-emerald-500 dark:text-obsidian-950 hover:bg-slate-800 dark:hover:bg-emerald-400 disabled:opacity-50 transition-colors cursor-pointer"
            >
              <Bell className="w-4 h-4" />
              {isSaving ? 'Saving Alert Rule...' : 'Activate Alert Rule'}
            </button>
          </form>

          {/* Existing Configured Rules */}
          <div className="pt-4 border-t border-slate-200 dark:border-slate-800 space-y-2.5">
            <h3 className="text-xs font-semibold text-slate-500 dark:text-slate-400">
              Configured Alert Rules ({rules.length})
            </h3>
            {rules.length === 0 ? (
              <p className="text-xs text-slate-500 dark:text-slate-400">
                No custom executive alerts configured yet.
              </p>
            ) : (
              <div className="space-y-2">
                {rules.map((rule) => (
                  <div
                    key={rule.id}
                    className="flex flex-wrap items-center justify-between gap-3 p-3 rounded-lg bg-slate-50 dark:bg-obsidian-850 border border-slate-200 dark:border-slate-800 text-xs"
                  >
                    <div className="min-w-0">
                      <div className="font-semibold text-slate-900 dark:text-white">
                        {rule.channel} · {rule.destination}
                      </div>
                      <div className="text-slate-500 dark:text-slate-400 font-mono tabular-nums mt-0.5">
                        {rule.minRelevanceScore}%+ · {rule.cadence} · {rule.sectors.join(', ')}
                      </div>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        type="button"
                        onClick={() => onToggleRule(rule)}
                        className={`px-2.5 py-1 rounded-md font-medium border cursor-pointer ${
                          rule.enabled
                            ? 'border-emerald-500/40 text-emerald-700 dark:text-emerald-400 bg-emerald-500/10'
                            : 'border-slate-300 dark:border-slate-700 text-slate-500'
                        }`}
                      >
                        {rule.enabled ? 'Active' : 'Paused'}
                      </button>
                      <button
                        type="button"
                        onClick={() => onDeleteRule(rule.id)}
                        aria-label="Delete alert rule"
                        className="p-1.5 text-slate-500 hover:text-rose-500 cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
