import React, { useState } from 'react';
import { Check, Copy, FileText, Loader2 } from 'lucide-react';
import { BoardroomMemoResult, PersonaConfig, PolicyDocument } from '../types';

interface BoardroomMemoViewProps {
  policies: PolicyDocument[];
  pinnedPolicyIds: string[];
  persona: PersonaConfig;
  onTogglePin: (policyId: string) => void;
}

const FOCUS_TOPICS = [
  'Capital Allocation & Project IRR Impact',
  'Compliance & Regulatory Penalty Mitigation',
  'Market Entry & Bidding Strategy (FDRE / CBG / GH2)',
  'Supply Chain Localization & M&A Valuation',
];

const HORIZONS = ['Q3–Q4 FY26 Immediate', 'FY 2026–28 Medium Term', '2026–2030 Strategic Cycle'];

export const BoardroomMemoView: React.FC<BoardroomMemoViewProps> = ({
  policies,
  pinnedPolicyIds,
  persona,
  onTogglePin,
}) => {
  const [focusTopic, setFocusTopic] = useState(FOCUS_TOPICS[0]);
  const [horizon, setHorizon] = useState(HORIZONS[0]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [memo, setMemo] = useState<BoardroomMemoResult | null>(null);
  const [copied, setCopied] = useState(false);

  const effectivePolicies =
    pinnedPolicyIds.length > 0
      ? policies.filter((p) => pinnedPolicyIds.includes(p.id))
      : [...policies]
          .sort(
            (a, b) =>
              (b.personaProfiles[persona.id]?.relevanceScore ?? 0) -
              (a.personaProfiles[persona.id]?.relevanceScore ?? 0)
          )
          .slice(0, 4);

  async function handleGenerateMemo(e: React.FormEvent) {
    e.preventDefault();
    setIsGenerating(true);
    setError(null);

    try {
      const response = await fetch('/api/analyst/memo', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          personaLabel: persona.label,
          personaMandate: persona.mandate,
          focusTopic,
          horizon,
          selectedPolicies: effectivePolicies.map((p) => ({
            ...p,
            relevanceScore: p.personaProfiles[persona.id]?.relevanceScore,
            personaImpact: p.personaProfiles[persona.id]?.impactSummary,
          })),
        }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Failed to generate Boardroom Memo.');
      }

      setMemo(data.memo as BoardroomMemoResult);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Unable to reach Gemini analyst service.');
    } finally {
      setIsGenerating(false);
    }
  }

  async function handleCopyMemo() {
    if (!memo) return;
    const text = [
      `# ${memo.title}`,
      `Prepared for: ${persona.label} | Focus: ${focusTopic} | Horizon: ${horizon}`,
      '',
      '## Executive Thesis',
      memo.executiveThesis,
      '',
      '## Capital Allocation Implications',
      ...memo.capitalAllocation.map((c) => `- ${c}`),
      '',
      '## Compliance Risk Matrix',
      ...memo.complianceRisks.map(
        (r) => `- [${r.agency}] Risk: ${r.risk} | Mitigation: ${r.mitigation}`
      ),
      '',
      '## 90-Day Strategic Actions',
      ...memo.strategicActions.map((a, idx) => `${idx + 1}. ${a}`),
      '',
      `Referenced Dockets: ${memo.referencedDockets.join(', ')}`,
    ].join('\n');

    await navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  return (
    <section className="space-y-5">
      <div className="pb-4 border-b border-slate-200 dark:border-slate-800">
        <h2 className="text-xl font-semibold text-slate-900 dark:text-white">
          Boardroom Memo Generator
        </h2>
        <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
          Synthesize pinned regulatory orders into an investment-committee-ready strategic memorandum for{' '}
          <span className="font-medium text-slate-900 dark:text-slate-200">{persona.label}</span>.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Memo Configuration Panel */}
        <form
          onSubmit={handleGenerateMemo}
          className="lg:col-span-4 bg-white dark:bg-obsidian-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 space-y-4"
        >
          <div>
            <label
              htmlFor="memo-focus"
              className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5"
            >
              Strategic Mandate Focus
            </label>
            <select
              id="memo-focus"
              value={focusTopic}
              onChange={(e) => setFocusTopic(e.target.value)}
              className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-obsidian-850 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/40"
            >
              {FOCUS_TOPICS.map((topic) => (
                <option key={topic} value={topic}>
                  {topic}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label
              htmlFor="memo-horizon"
              className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5"
            >
              Planning Horizon
            </label>
            <select
              id="memo-horizon"
              value={horizon}
              onChange={(e) => setHorizon(e.target.value)}
              className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-obsidian-850 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/40"
            >
              {HORIZONS.map((h) => (
                <option key={h} value={h}>
                  {h}
                </option>
              ))}
            </select>
          </div>

          <div>
            <div className="flex items-center justify-between text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
              <span>Policy Context ({effectivePolicies.length} selected)</span>
              <span className="font-normal text-slate-500 dark:text-slate-400">
                {pinnedPolicyIds.length > 0 ? 'Pinned selection' : 'Top persona matches'}
              </span>
            </div>
            <div className="space-y-1.5 max-h-64 overflow-y-auto pr-1">
              {policies.map((p) => {
                const checked = pinnedPolicyIds.includes(p.id);
                const score = p.personaProfiles[persona.id]?.relevanceScore ?? 75;
                return (
                  <label
                    key={p.id}
                    className="flex items-start gap-2.5 p-2 rounded-lg border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-obsidian-850 cursor-pointer text-xs"
                  >
                    <input
                      type="checkbox"
                      checked={checked}
                      onChange={() => onTogglePin(p.id)}
                      className="mt-0.5 rounded border-slate-300 text-emerald-500 focus:ring-emerald-500"
                    />
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center justify-between gap-2 text-slate-500 dark:text-slate-400">
                        <span className="font-semibold text-slate-800 dark:text-slate-200">
                          {p.agency}
                        </span>
                        <span className="font-mono tabular-nums">{score}%</span>
                      </div>
                      <div className="text-slate-700 dark:text-slate-300 line-clamp-1">{p.title}</div>
                    </div>
                  </label>
                );
              })}
            </div>
          </div>

          <button
            type="submit"
            disabled={isGenerating}
            className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-semibold rounded-lg bg-slate-900 text-white dark:bg-emerald-500 dark:text-obsidian-950 hover:bg-slate-800 dark:hover:bg-emerald-400 disabled:opacity-60 transition-colors cursor-pointer"
          >
            {isGenerating ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Drafting Boardroom Memo...
              </>
            ) : (
              <>
                <FileText className="w-4 h-4" />
                Generate Boardroom Memo
              </>
            )}
          </button>

          {error && (
            <div className="p-3 rounded-lg bg-rose-50 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-800 text-xs text-rose-700 dark:text-rose-300">
              {error}
            </div>
          )}
        </form>

        {/* Rendered Boardroom Memo Output */}
        <div className="lg:col-span-8 bg-white dark:bg-obsidian-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 min-h-[420px]">
          {!memo && !isGenerating && (
            <div className="h-full flex flex-col items-center justify-center text-center py-16 px-6">
              <FileText className="w-10 h-10 text-slate-300 dark:text-slate-700 mb-3" />
              <h3 className="text-base font-semibold text-slate-900 dark:text-white mb-1">
                Ready for Boardroom Synthesis
              </h3>
              <p className="text-sm text-slate-500 dark:text-slate-400 max-w-md">
                Select a strategic focus and click Generate Boardroom Memo to produce a Gemini-authored briefing covering capital allocation, compliance risk, and 90-day execution steps.
              </p>
            </div>
          )}

          {isGenerating && (
            <div className="space-y-4 py-6">
              <div className="h-6 bg-slate-200 dark:bg-obsidian-800 rounded w-3/4 animate-pulse" />
              <div className="h-4 bg-slate-100 dark:bg-obsidian-850 rounded w-full animate-pulse" />
              <div className="h-4 bg-slate-100 dark:bg-obsidian-850 rounded w-5/6 animate-pulse" />
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4">
                <div className="h-28 bg-slate-100 dark:bg-obsidian-850 rounded-lg animate-pulse" />
                <div className="h-28 bg-slate-100 dark:bg-obsidian-850 rounded-lg animate-pulse" />
              </div>
            </div>
          )}

          {memo && !isGenerating && (
            <div className="space-y-6">
              <div className="flex flex-wrap items-start justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
                <div>
                  <div className="text-xs text-emerald-700 dark:text-emerald-400 font-semibold mb-1">
                    {persona.label} · {horizon}
                  </div>
                  <h3 className="text-xl font-bold text-slate-900 dark:text-white">
                    {memo.title}
                  </h3>
                </div>
                <button
                  type="button"
                  onClick={handleCopyMemo}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-obsidian-850 transition-colors cursor-pointer"
                >
                  {copied ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-500" />
                      Copied Markdown
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      Copy Memo
                    </>
                  )}
                </button>
              </div>

              <div>
                <h4 className="text-xs font-semibold text-slate-500 dark:text-slate-400 mb-2">
                  Executive Thesis
                </h4>
                <p className="text-sm text-slate-800 dark:text-slate-200 leading-relaxed">
                  {memo.executiveThesis}
                </p>
              </div>

              <div>
                <h4 className="text-xs font-semibold text-slate-500 dark:text-slate-400 mb-2">
                  Capital Allocation & Margin Implications
                </h4>
                <ul className="space-y-2 list-disc list-inside">
                  {memo.capitalAllocation.map((item, idx) => (
                    <li
                      key={idx}
                      className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed"
                    >
                      {item}
                    </li>
                  ))}
                </ul>
              </div>

              <div>
                <h4 className="text-xs font-semibold text-slate-500 dark:text-slate-400 mb-2">
                  Compliance Risk Matrix
                </h4>
                <div className="overflow-x-auto border border-slate-200 dark:border-slate-800 rounded-lg">
                  <table className="w-full text-left text-xs sm:text-sm">
                    <thead className="bg-slate-50 dark:bg-obsidian-850 text-slate-600 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800">
                      <tr>
                        <th className="py-2.5 px-3 font-semibold">Agency</th>
                        <th className="py-2.5 px-3 font-semibold">Regulatory Exposure</th>
                        <th className="py-2.5 px-3 font-semibold">Mitigation</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                      {memo.complianceRisks.map((row, idx) => (
                        <tr key={idx}>
                          <td className="py-2.5 px-3 font-semibold text-slate-900 dark:text-white whitespace-nowrap">
                            {row.agency}
                          </td>
                          <td className="py-2.5 px-3 text-slate-700 dark:text-slate-300">{row.risk}</td>
                          <td className="py-2.5 px-3 text-slate-700 dark:text-slate-300">
                            {row.mitigation}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              <div>
                <h4 className="text-xs font-semibold text-slate-500 dark:text-slate-400 mb-2">
                  90-Day Strategic Actions
                </h4>
                <ol className="space-y-2 list-decimal list-inside text-sm text-slate-800 dark:text-slate-200">
                  {memo.strategicActions.map((act, idx) => (
                    <li key={idx}>{act}</li>
                  ))}
                </ol>
              </div>

              <div className="pt-3 border-t border-slate-200 dark:border-slate-800 text-xs text-slate-500 dark:text-slate-400 font-mono">
                Cited Dockets: {memo.referencedDockets.join(' · ')}
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};
