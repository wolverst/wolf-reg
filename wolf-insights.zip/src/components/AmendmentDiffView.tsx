import React, { useMemo, useState } from 'react';
import { ArrowRight, MessageSquareText } from 'lucide-react';
import { PersonaConfig, PolicyDocument, Sector, Severity } from '../types';

interface AmendmentDiffViewProps {
  policies: PolicyDocument[];
  persona: PersonaConfig;
  onAskAnalyst: (policy: PolicyDocument) => void;
}

const SEVERITIES: ('All' | Severity)[] = ['All', 'Critical', 'Material', 'Procedural'];
const SECTORS: ('All' | Sector)[] = [
  'All',
  'Solar',
  'Biogas & CBG',
  'Green Hydrogen',
  'Grid & BESS',
];

export const AmendmentDiffView: React.FC<AmendmentDiffViewProps> = ({
  policies,
  persona,
  onAskAnalyst,
}) => {
  const [severityFilter, setSeverityFilter] = useState<'All' | Severity>('All');
  const [sectorFilter, setSectorFilter] = useState<'All' | Sector>('All');

  const filtered = useMemo(() => {
    return policies
      .filter((p) => (severityFilter === 'All' ? true : p.severity === severityFilter))
      .filter((p) => (sectorFilter === 'All' ? true : p.sector === sectorFilter))
      .sort(
        (a, b) =>
          (b.personaProfiles[persona.id]?.relevanceScore ?? 0) -
          (a.personaProfiles[persona.id]?.relevanceScore ?? 0)
      );
  }, [policies, severityFilter, sectorFilter, persona.id]);

  return (
    <section className="space-y-5">
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div>
          <h2 className="text-xl font-semibold text-slate-900 dark:text-white">
            Amendment Diff Tracker
          </h2>
          <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
            Side-by-side comparison of superseded regulatory clauses against newly notified statutory rules.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-obsidian-900 border border-slate-200 dark:border-slate-800 rounded-lg">
            {SEVERITIES.map((sev) => (
              <button
                key={sev}
                type="button"
                onClick={() => setSeverityFilter(sev)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  severityFilter === sev
                    ? 'bg-white dark:bg-obsidian-800 text-slate-900 dark:text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {sev}
              </button>
            ))}
          </div>

          <select
            aria-label="Filter amendments by sector"
            value={sectorFilter}
            onChange={(e) => setSectorFilter(e.target.value as 'All' | Sector)}
            className="px-3 py-2 text-xs font-medium bg-white dark:bg-obsidian-900 border border-slate-200 dark:border-slate-800 rounded-lg text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500/40"
          >
            {SECTORS.map((sec) => (
              <option key={sec} value={sec}>
                {sec === 'All' ? 'All Sectors' : sec}
              </option>
            ))}
          </select>
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="bg-white dark:bg-obsidian-900 border border-slate-200 dark:border-slate-800 rounded-xl p-10 text-center">
          <p className="text-sm text-slate-600 dark:text-slate-400 mb-3">
            No regulatory amendments match the selected severity and sector filters.
          </p>
          <button
            type="button"
            onClick={() => {
              setSeverityFilter('All');
              setSectorFilter('All');
            }}
            className="px-4 py-2 text-xs font-medium bg-slate-900 text-white dark:bg-emerald-500 dark:text-obsidian-950 rounded-lg cursor-pointer"
          >
            Reset Filters
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {filtered.map((policy) => {
            const score = policy.personaProfiles[persona.id]?.relevanceScore ?? 75;
            return (
              <div
                key={policy.id}
                className="bg-white dark:bg-obsidian-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden"
              >
                <div className="px-5 py-3.5 bg-slate-50 dark:bg-obsidian-850 border-b border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400 mb-1">
                      <span className="font-semibold text-slate-900 dark:text-white">
                        {policy.agency}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>{policy.amendmentClause}</span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono text-[11px]">{policy.docketNumber}</span>
                    </div>
                    <h3 className="text-sm sm:text-base font-semibold text-slate-900 dark:text-white">
                      {policy.title}
                    </h3>
                  </div>

                  <div className="flex items-center gap-3 shrink-0">
                    <span className="text-xs font-mono tabular-nums text-emerald-700 dark:text-emerald-400 font-semibold">
                      {score}% ({persona.shortLabel})
                    </span>
                    <button
                      type="button"
                      onClick={() => onAskAnalyst(policy)}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-white dark:hover:bg-obsidian-800 transition-colors cursor-pointer"
                    >
                      <MessageSquareText className="w-3.5 h-3.5" />
                      Query Clause
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-11">
                  <div className="lg:col-span-5 p-4 sm:p-5 bg-rose-50/30 dark:bg-rose-950/10">
                    <div className="text-xs font-semibold text-rose-700 dark:text-rose-400 mb-2">
                      Superseded Rule
                    </div>
                    <p className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
                      {policy.supersededRule}
                    </p>
                  </div>

                  <div className="hidden lg:flex lg:col-span-1 items-center justify-center border-x border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-obsidian-950/40">
                    <ArrowRight className="w-4 h-4 text-slate-400" />
                  </div>

                  <div className="lg:col-span-5 p-4 sm:p-5 bg-emerald-50/30 dark:bg-emerald-950/10 border-t lg:border-t-0 border-slate-200 dark:border-slate-800">
                    <div className="flex items-center justify-between gap-2 mb-2">
                      <span className="text-xs font-semibold text-emerald-700 dark:text-emerald-400">
                        Notified Amendment
                      </span>
                      <span className="text-[11px] font-mono tabular-nums text-slate-500 dark:text-slate-400">
                        Effective {policy.effectiveDate}
                      </span>
                    </div>
                    <p className="text-sm text-slate-900 dark:text-slate-100 leading-relaxed">
                      {policy.newRule}
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </section>
  );
};
