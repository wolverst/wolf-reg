import React, { useEffect, useRef, useState } from 'react';
import { Loader2, Send, Trash2, X } from 'lucide-react';
import { AnalystMessage, PersonaConfig, PolicyDocument } from '../types';

interface AnalystDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  persona: PersonaConfig;
  policies: PolicyDocument[];
  focusedPolicy: PolicyDocument | null;
  initialPrompt: string | null;
  onClearInitialPrompt: () => void;
}

const PERSONA_PROMPTS: Record<string, string[]> = {
  investor: [
    'Which notified policies lift project equity IRR by >150 bps in FY27?',
    'How does the MoP ISTS waiver carve-out affect Rajasthan solar wheeling?',
    'Compare capex risk from ALMM List-II vs. BESS VGF Phase-II grants.',
  ],
  startup: [
    'What immediate tender bottlenecks does ALMM List-II create for C&I EPCs?',
    'Summarize FDRE-IV Green-Shoe eligibility and BG2 encashment triggers.',
    'Where can a grid-software startup monetize CEA GFM & 1s telemetry rules?',
  ],
  biogas: [
    'Calculate the combined margin impact of SATAT 2.0 + IREDA 75 bps debt subvention.',
    'How does G.S.R. 612(E) enforce the 5% CBO blending floor on CGDs?',
    'What documentation is needed to claim ₹1,450/tonne biomass aggregation support?',
  ],
  climatetech: [
    'Detail the technical specs mandated under CEA Grid-Forming & 1s RLDC telemetry.',
    'What traceability software opportunities arise from SATAT 2.0 and CBO registries?',
    'How do CERC GNA 2nd Amendment rules impact co-located BESS EMS controllers?',
  ],
};

export const AnalystDrawer: React.FC<AnalystDrawerProps> = ({
  isOpen,
  onClose,
  persona,
  policies,
  focusedPolicy,
  initialPrompt,
  onClearInitialPrompt,
}) => {
  const [messages, setMessages] = useState<AnalystMessage[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  async function submitQuestion(textToAsk: string) {
    const trimmed = textToAsk.trim();
    if (!trimmed || isLoading) return;

    const userMsg: AnalystMessage = {
      id: `u-${Date.now()}`,
      role: 'user',
      text: trimmed,
      timestamp: new Date().toLocaleTimeString('en-IN', {
        hour: '2-digit',
        minute: '2-digit',
      }),
    };

    const nextHistory = [...messages, userMsg];
    setMessages(nextHistory);
    setInput('');
    setError(null);
    setIsLoading(true);

    try {
      const contextPolicies = focusedPolicy
        ? [focusedPolicy, ...policies.filter((p) => p.id !== focusedPolicy.id)]
        : policies;

      const response = await fetch('/api/analyst/ask', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          question: trimmed,
          personaLabel: persona.label,
          personaMandate: persona.mandate,
          activePolicies: contextPolicies.map((p) => ({
            ...p,
            relevanceScore: p.personaProfiles[persona.id]?.relevanceScore,
            personaImpact: p.personaProfiles[persona.id]?.impactSummary,
          })),
          history: nextHistory.map((m) => ({ role: m.role, text: m.text })),
        }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'wolfreg AI Analyst failed to respond.');
      }

      const assistantMsg: AnalystMessage = {
        id: `a-${Date.now()}`,
        role: 'assistant',
        text: data.answer,
        citedDockets: data.citedDockets,
        timestamp: new Date().toLocaleTimeString('en-IN', {
          hour: '2-digit',
          minute: '2-digit',
        }),
      };

      setMessages((prev) => [...prev, assistantMsg]);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Unable to reach Gemini analyst.');
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    if (isOpen && initialPrompt) {
      submitQuestion(initialPrompt);
      onClearInitialPrompt();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isOpen, initialPrompt]);

  if (!isOpen) return null;

  const suggestions = PERSONA_PROMPTS[persona.id] || PERSONA_PROMPTS.investor;

  return (
    <div
      className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-[2px]"
      role="dialog"
      aria-modal="true"
      aria-label="wolfreg AI Regulatory Analyst"
    >
      <div className="w-full max-w-xl bg-white dark:bg-obsidian-950 border-l border-slate-200 dark:border-slate-800 h-full flex flex-col shadow-2xl">
        {/* Drawer Header */}
        <div className="px-5 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-4">
          <div className="min-w-0">
            <h2 className="text-base font-semibold text-slate-900 dark:text-white truncate">
              wolfreg AI Regulatory Analyst
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
              Persona: {persona.label} · Grounded in {policies.length} active orders
            </p>
          </div>
          <div className="flex items-center gap-1.5 shrink-0">
            {messages.length > 0 && (
              <button
                type="button"
                onClick={() => setMessages([])}
                title="Clear conversation"
                className="p-2 text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white rounded-lg hover:bg-slate-100 dark:hover:bg-obsidian-900 transition-colors cursor-pointer"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            )}
            <button
              type="button"
              onClick={onClose}
              aria-label="Close wolfreg AI Analyst"
              className="p-2 text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white rounded-lg hover:bg-slate-100 dark:hover:bg-obsidian-900 transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Focused Policy Context Strip */}
        {focusedPolicy && (
          <div className="px-5 py-2.5 bg-slate-50 dark:bg-obsidian-900 border-b border-slate-200 dark:border-slate-800 text-xs flex items-center justify-between gap-2">
            <span className="truncate text-slate-700 dark:text-slate-300">
              Scoped Policy:{' '}
              <strong className="font-semibold text-slate-900 dark:text-white">
                {focusedPolicy.agency} · {focusedPolicy.docketNumber}
              </strong>
            </span>
            <span className="font-mono tabular-nums text-emerald-600 dark:text-emerald-400 shrink-0">
              {focusedPolicy.personaProfiles[persona.id]?.relevanceScore ?? 75}% Match
            </span>
          </div>
        )}

        {/* Messages Scroll Viewport */}
        <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4">
          {messages.length === 0 && (
            <div className="space-y-4 py-4">
              <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                Ask any regulatory, tariff, PPA bankability, or compliance question across the live Indian clean-energy policy corpus. Answers are synthesized for your active{' '}
                <strong className="font-semibold text-slate-900 dark:text-white">
                  {persona.label}
                </strong>{' '}
                perspective.
              </p>

              <div className="space-y-2">
                <div className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                  Suggested Prompts for {persona.shortLabel}
                </div>
                {suggestions.map((q) => (
                  <button
                    key={q}
                    type="button"
                    onClick={() => submitQuestion(q)}
                    className="w-full text-left px-3.5 py-2.5 text-xs sm:text-sm rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-obsidian-900 text-slate-800 dark:text-slate-200 hover:border-emerald-500/60 transition-colors cursor-pointer"
                  >
                    {q}
                  </button>
                ))}
              </div>
            </div>
          )}

          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`rounded-xl p-4 text-sm leading-relaxed ${
                msg.role === 'user'
                  ? 'bg-slate-900 text-white dark:bg-obsidian-850 dark:text-slate-100 ml-8 border border-slate-800'
                  : 'bg-slate-50 dark:bg-obsidian-900 text-slate-800 dark:text-slate-200 mr-4 border border-slate-200 dark:border-slate-800'
              }`}
            >
              <div className="flex items-center justify-between text-[11px] opacity-70 mb-1.5">
                <span className="font-semibold">
                  {msg.role === 'user' ? persona.shortLabel : 'wolfreg AI Analyst'}
                </span>
                <span className="font-mono tabular-nums">{msg.timestamp}</span>
              </div>
              <div className="whitespace-pre-wrap">{msg.text}</div>

              {msg.citedDockets && msg.citedDockets.length > 0 && (
                <div className="mt-3 pt-2.5 border-t border-slate-200 dark:border-slate-800 text-xs text-slate-500 dark:text-slate-400">
                  <span className="font-semibold text-slate-700 dark:text-slate-300">
                    Cited Authorities:{' '}
                  </span>
                  {msg.citedDockets.map((d) => `${d.agency} (${d.docketNumber})`).join(' · ')}
                </div>
              )}
            </div>
          ))}

          {isLoading && (
            <div className="flex items-center gap-2.5 px-4 py-3 rounded-xl bg-slate-50 dark:bg-obsidian-900 border border-slate-200 dark:border-slate-800 text-xs text-slate-600 dark:text-slate-300 mr-8">
              <Loader2 className="w-4 h-4 animate-spin text-emerald-500" />
              Synthesizing regulatory impact via Gemini...
            </div>
          )}

          {error && (
            <div className="p-3 rounded-lg bg-rose-50 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-800 text-xs text-rose-700 dark:text-rose-300">
              {error}
            </div>
          )}

          <div ref={endRef} />
        </div>

        {/* Input Form */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            submitQuestion(input);
          }}
          className="p-4 border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-obsidian-950"
        >
          <div className="flex items-center gap-2">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={`Ask about MNRE, CERC, SECI, CBG, or ISTS rules...`}
              className="flex-1 px-3.5 py-2.5 text-sm bg-slate-50 dark:bg-obsidian-900 border border-slate-200 dark:border-slate-800 rounded-lg text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500/40"
            />
            <button
              type="submit"
              disabled={!input.trim() || isLoading}
              aria-label="Send question"
              className="px-4 py-2.5 rounded-lg bg-slate-900 text-white dark:bg-emerald-500 dark:text-obsidian-950 hover:bg-slate-800 dark:hover:bg-emerald-400 disabled:opacity-50 transition-colors cursor-pointer shrink-0"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
