import React, { useState } from 'react';
import {
  ChevronDown,
  ChevronUp,
  ExternalLink,
  MessageSquareText,
  Pin,
  PinOff,
} from 'lucide-react';
import { PersonaConfig, PolicyDocument } from '../types';

interface PolicyCardProps {
  policy: PolicyDocument;
  persona: PersonaConfig;
  isPinned: boolean;
  onTogglePin: (policyId: string) => void;
  onAskAnalyst: (policy: PolicyDocument) => void;
}

export const PolicyCard: React.FC<PolicyCardProps> = ({
  policy,
  persona,
  isPinned,
  onTogglePin,
  onAskAnalyst,
}) => {
  const [diffExpanded, setDiffExpanded] = useState(false);
  const profile = policy.personaProfiles[persona.id];
  const score = profile?.relevanceScore ?? 75;
  const impact = profile?.impactSummary ?? policy.aiSummary;

  const severityTextClass =
    policy.severity === 'Critical'
      ? 'text-rose-600 dark:text-rose-400 font-semibold'
      : policy.severity === 'Material'
        ? 'text-amber-600 dark:text-gold-400 font-semibold'
        : 'text-slate-600 dark:text-slate-400 font-medium';

  const scoreTextClass =
    score >= 85
      ? 'text-emerald-600 dark:text-emerald-500'
      : score >= 70
        ? 'text-amber-600 dark:text-gold-400'
        : 'text-slate-500 dark:text-slate-400';

  return (
    <article className="bg-white dark:bg-obsidian-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 transition-colors hover:border-slate-300 dark:hover:border-slate-700">
      {/* Unboxed Metadata Line + Tabular Relevance Score */}
      <div className="flex flex-wrap items-center justify-between gap-3 text-xs text-slate-500 dark:text-slate-400 mb-2.5">
        <div className="flex flex-wrap items-center gap-2 min-w-0">
          <span className="font-semibold text-slate-900 dark:text-slate-200">
            {policy.agency}
          </span>
          <span aria-hidden="true">·</span>
          <span>{policy.sector}</span>
          <span aria-hidden="true">·</span>
          <span className="font-mono text-[11px] truncate max-w-[260px]" title={policy.docketNumber}>
            {policy.docketNumber}
          </span>
          <span aria-hidden="true">·</span>
          <span className="font-mono tabular-nums">{policy.publishedDate}</span>
          <span aria-hidden="true">·</span>
          <span className={severityTextClass}>{policy.severity}</span>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <span className="text-slate-500 dark:text-slate-400">
            Effective{' '}
            <span className="font-mono tabular-nums text-slate-800 dark:text-slate-200">
              {policy.effectiveDate}
            </span>
          </span>
          <span aria-hidden="true" className="text-slate-300 dark:text-slate-700">
            |
          </span>
          <span className={`font-mono tabular-nums text-sm font-semibold ${scoreTextClass}`}>
            {score}% Relevance
          </span>
        </div>
      </div>

      {/* Policy Title */}
      <h3 className="text-base sm:text-lg font-semibold text-slate-900 dark:text-white leading-snug mb-2">
        {policy.title}
      </h3>

      {/* 15-Second AI Summary */}
      <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed mb-4">
        {policy.aiSummary}
      </p>

      {/* Persona-Specific Business Impact */}
      <div className="bg-slate-50 dark:bg-obsidian-850 border border-slate-200 dark:border-slate-800 rounded-lg px-4 py-3 mb-4">
        <div className="flex items-center justify-between gap-2 mb-1">
          <span className="text-xs font-semibold text-emerald-700 dark:text-emerald-500">
            Business Impact — {persona.label}
          </span>
          <span className="text-[11px] font-mono tabular-nums text-slate-500 dark:text-slate-400">
            {persona.focusMetrics}
          </span>
        </div>
        <p className="text-sm text-slate-800 dark:text-slate-200 leading-relaxed">
          {impact}
        </p>
      </div>

      {/* Expandable Amendment Diff Box */}
      {diffExpanded && (
        <div className="mb-4 border border-slate-200 dark:border-slate-800 rounded-lg overflow-hidden">
          <div className="px-4 py-2 bg-slate-100 dark:bg-obsidian-850 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs">
            <span className="font-semibold text-slate-800 dark:text-slate-200">
              Clause Diff: {policy.amendmentClause}
            </span>
            <span className="font-mono text-slate-500 dark:text-slate-400">
              Redline Comparison
            </span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:divide-x divide-slate-200 dark:divide-slate-800">
            <div className="p-3.5 bg-rose-50/40 dark:bg-rose-950/10">
              <div className="text-xs font-semibold text-rose-700 dark:text-rose-400 mb-1.5">
                Superseded Rule
              </div>
              <p className="text-xs sm:text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
                {policy.supersededRule}
              </p>
            </div>
            <div className="p-3.5 bg-emerald-50/40 dark:bg-emerald-950/10">
              <div className="text-xs font-semibold text-emerald-700 dark:text-emerald-400 mb-1.5">
                Newly Notified Rule
              </div>
              <p className="text-xs sm:text-sm text-slate-800 dark:text-slate-200 leading-relaxed">
                {policy.newRule}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Action Footer */}
      <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-100 dark:border-slate-800/80">
        <button
          type="button"
          onClick={() => setDiffExpanded((prev) => !prev)}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-obsidian-850 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          {diffExpanded ? (
            <>
              <ChevronUp className="w-3.5 h-3.5" />
              Hide Amendment Diff
            </>
          ) : (
            <>
              <ChevronDown className="w-3.5 h-3.5" />
              View Amendment Diff
            </>
          )}
        </button>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => onTogglePin(policy.id)}
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md border transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              isPinned
                ? 'border-emerald-500/50 bg-emerald-500/10 text-emerald-700 dark:text-emerald-400'
                : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-obsidian-850'
            }`}
          >
            {isPinned ? (
              <>
                <PinOff className="w-3.5 h-3.5" />
                Pinned to Memo
              </>
            ) : (
              <>
                <Pin className="w-3.5 h-3.5" />
                Include in Memo
              </>
            )}
          </button>

          <button
            type="button"
            onClick={() => onAskAnalyst(policy)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md bg-slate-900 text-white dark:bg-emerald-500 dark:text-obsidian-950 hover:bg-slate-800 dark:hover:bg-emerald-400 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <MessageSquareText className="w-3.5 h-3.5" />
            Analyze with wolfreg AI
          </button>

          <a
            href={policy.sourceUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white transition-colors whitespace-nowrap shrink-0"
          >
            Source
            <ExternalLink className="w-3 h-3" />
          </a>
        </div>
      </div>
    </article>
  );
};
