import React, { useEffect, useMemo, useState } from 'react';
import { onAuthStateChanged, User } from 'firebase/auth';
import {
  Bell,
  Check,
  Copy,
  LogIn,
  LogOut,
  Moon,
  Search,
  SlidersHorizontal,
  Sun,
} from 'lucide-react';
import { AmendmentDiffView } from './components/AmendmentDiffView';
import { AnalystDrawer } from './components/AnalystDrawer';
import { BoardroomMemoView } from './components/BoardroomMemoView';
import { PolicyCard } from './components/PolicyCard';
import { PortalsHubView } from './components/PortalsHubView';
import { SmartAlertModal } from './components/SmartAlertModal';
import { INITIAL_PORTALS, PERSONAS, SAMPLE_POLICIES } from './data/policies';
import {
  auth,
  fetchPoliciesWithFallback,
  fetchUserAlertRules,
  removeUserAlertRule,
  saveUserAlertRule,
  seedSamplePoliciesToFirestore,
  signInWithGoogle,
  signOutUser,
  testFirestoreConnection,
} from './lib/firebase';
import {
  Agency,
  AlertRule,
  PersonaId,
  PolicyDocument,
  PortalStatus,
  Sector,
  WorkspaceView,
} from './types';

const AGENCIES: ('All' | Agency)[] = [
  'All',
  'MNRE',
  'CERC',
  'SECI',
  'IREDA',
  'MoP',
  'CEA',
  'PIB',
  'e-Gazette',
];

const SECTORS: ('All' | Sector)[] = [
  'All',
  'Solar',
  'Biogas & CBG',
  'Green Hydrogen',
  'Grid & BESS',
];

const LOCAL_ALERTS_KEY = 'wolf_insights_alert_rules';

export default function App() {
  const [activeView, setActiveView] = useState<WorkspaceView>('feed');
  const [personaId, setPersonaId] = useState<PersonaId>('investor');
  const [policies, setPolicies] = useState<PolicyDocument[]>(SAMPLE_POLICIES);
  const [dataSource, setDataSource] = useState<'firestore' | 'fallback'>('fallback');
  const [isLoadingPolicies, setIsLoadingPolicies] = useState(true);
  const [isDark, setIsDark] = useState<boolean>(() => {
    if (typeof document !== 'undefined') {
      return document.documentElement.classList.contains('dark');
    }
    return true;
  });

  // Filters
  const [agencyFilter, setAgencyFilter] = useState<'All' | Agency>('All');
  const [sectorFilter, setSectorFilter] = useState<'All' | Sector>('All');
  const [highImpactOnly, setHighImpactOnly] = useState(false);
  const [feedQuery, setFeedQuery] = useState('');

  // Portals & Syncing
  const [portals, setPortals] = useState<PortalStatus[]>(INITIAL_PORTALS);
  const [syncingAgency, setSyncingAgency] = useState<Agency | 'ALL' | null>(null);
  const [isSeeding, setIsSeeding] = useState(false);

  // Analyst & Memo State
  const [analystOpen, setAnalystOpen] = useState(false);
  const [analystSearchInput, setAnalystSearchInput] = useState('');
  const [analystInitialPrompt, setAnalystInitialPrompt] = useState<string | null>(null);
  const [focusedPolicy, setFocusedPolicy] = useState<PolicyDocument | null>(null);
  const [pinnedPolicyIds, setPinnedPolicyIds] = useState<string[]>([
    'cerc-gna-2nd-amendment-2026',
    'mop-ists-waiver-gh2-psp-2026',
  ]);

  // Alerts & Auth State
  const [alertModalOpen, setAlertModalOpen] = useState(false);
  const [alertRules, setAlertRules] = useState<AlertRule[]>(() => {
    try {
      const raw = localStorage.getItem(LOCAL_ALERTS_KEY);
      return raw ? (JSON.parse(raw) as AlertRule[]) : [];
    } catch {
      return [];
    }
  });
  const [user, setUser] = useState<User | null>(null);

  // Toast / Copy Feedback
  const [digestCopied, setDigestCopied] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const activePersona = useMemo(
    () => PERSONAS.find((p) => p.id === personaId) || PERSONAS[0],
    [personaId]
  );

  function showToast(msg: string) {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((curr) => (curr === msg ? null : curr));
    }, 3200);
  }

  // Boot: test Firestore connection + load policies + listen to Auth
  useEffect(() => {
    let mounted = true;
    async function initData() {
      setIsLoadingPolicies(true);
      await testFirestoreConnection();
      const result = await fetchPoliciesWithFallback();
      if (mounted) {
        setPolicies(result.policies);
        setDataSource(result.source);
        setIsLoadingPolicies(false);
      }
    }
    initData();

    const unsub = onAuthStateChanged(auth, async (currentUser) => {
      if (!mounted) return;
      setUser(currentUser);
      if (currentUser && currentUser.emailVerified) {
        try {
          const cloudRules = await fetchUserAlertRules(currentUser.uid);
          if (cloudRules.length > 0 && mounted) {
            setAlertRules(cloudRules);
          }
        } catch {
          // Keep local rules if Firestore rules fetch fails
        }
      }
    });

    return () => {
      mounted = false;
      unsub();
    };
  }, []);

  // Theme Toggle
  function handleToggleTheme() {
    const nextDark = !isDark;
    setIsDark(nextDark);
    if (nextDark) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('wolf_theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('wolf_theme', 'light');
    }
  }

  // Filtered & Persona-Ranked Policies
  const filteredPolicies = useMemo(() => {
    const q = feedQuery.trim().toLowerCase();
    return policies
      .filter((p) => (agencyFilter === 'All' ? true : p.agency === agencyFilter))
      .filter((p) => (sectorFilter === 'All' ? true : p.sector === sectorFilter))
      .filter((p) => {
        if (!highImpactOnly) return true;
        return (p.personaProfiles[personaId]?.relevanceScore ?? 0) >= 85;
      })
      .filter((p) => {
        if (!q) return true;
        return (
          p.title.toLowerCase().includes(q) ||
          p.docketNumber.toLowerCase().includes(q) ||
          p.aiSummary.toLowerCase().includes(q) ||
          p.agency.toLowerCase().includes(q) ||
          p.sector.toLowerCase().includes(q)
        );
      })
      .sort(
        (a, b) =>
          (b.personaProfiles[personaId]?.relevanceScore ?? 0) -
          (a.personaProfiles[personaId]?.relevanceScore ?? 0)
      );
  }, [policies, agencyFilter, sectorFilter, highImpactOnly, feedQuery, personaId]);

  const highImpactCount = useMemo(
    () =>
      policies.filter((p) => (p.personaProfiles[personaId]?.relevanceScore ?? 0) >= 85).length,
    [policies, personaId]
  );

  const criticalCount = useMemo(
    () => policies.filter((p) => p.severity === 'Critical').length,
    [policies]
  );

  // Handlers
  function handleTogglePin(policyId: string) {
    setPinnedPolicyIds((prev) =>
      prev.includes(policyId) ? prev.filter((id) => id !== policyId) : [...prev, policyId]
    );
  }

  function handleAskPolicyAnalyst(policy: PolicyDocument) {
    setFocusedPolicy(policy);
    setAnalystInitialPrompt(
      `Analyze ${policy.agency} order (${policy.docketNumber}) — "${policy.title}" — for a ${activePersona.label}. Highlight tariff/margin exposure and immediate compliance actions.`
    );
    setAnalystOpen(true);
  }

  function handleAnalystBarSubmit(e: React.FormEvent) {
    e.preventDefault();
    setFocusedPolicy(null);
    if (analystSearchInput.trim()) {
      setAnalystInitialPrompt(analystSearchInput.trim());
      setAnalystSearchInput('');
    }
    setAnalystOpen(true);
  }

  async function handleCopy60SecondDigest() {
    const topThree = [...policies]
      .sort(
        (a, b) =>
          (b.personaProfiles[personaId]?.relevanceScore ?? 0) -
          (a.personaProfiles[personaId]?.relevanceScore ?? 0)
      )
      .slice(0, 4);

    const lines = [
      `WOLFREG — 60-SECOND EXECUTIVE DIGEST (${activePersona.label.toUpperCase()})`,
      `Generated: ${new Date().toLocaleDateString('en-IN', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      })}`,
      '',
      ...topThree.map((p, i) => {
        const profile = p.personaProfiles[personaId];
        return `${i + 1}. [${p.agency} | ${p.sector} | ${profile?.relevanceScore ?? 80}% Match] ${p.title}\n   Docket: ${p.docketNumber} (Effective ${p.effectiveDate})\n   Impact: ${profile?.impactSummary ?? p.aiSummary}`;
      }),
    ];

    await navigator.clipboard.writeText(lines.join('\n\n'));
    setDigestCopied(true);
    showToast(`Copied 60-second digest for ${activePersona.shortLabel} to clipboard.`);
    setTimeout(() => setDigestCopied(false), 2200);
  }

  async function handleSyncPortal(agency: Agency) {
    setSyncingAgency(agency);
    const result = await fetchPoliciesWithFallback();
    setTimeout(() => {
      setPolicies(result.policies);
      setDataSource(result.source);
      setPortals((prev) =>
        prev.map((p) => (p.agency === agency ? { ...p, lastSyncedMinutesAgo: 0 } : p))
      );
      setSyncingAgency(null);
      showToast(`${agency} portal synced cleanly.`);
    }, 450);
  }

  async function handleSyncAllPortals() {
    setSyncingAgency('ALL');
    const result = await fetchPoliciesWithFallback();
    setTimeout(() => {
      setPolicies(result.policies);
      setDataSource(result.source);
      setPortals((prev) => prev.map((p) => ({ ...p, lastSyncedMinutesAgo: 0 })));
      setSyncingAgency(null);
      showToast('All 8 government regulatory portals synced.');
    }, 650);
  }

  async function handleSeedFirestore() {
    setIsSeeding(true);
    try {
      const count = await seedSamplePoliciesToFirestore();
      const result = await fetchPoliciesWithFallback();
      setPolicies(result.policies);
      setDataSource(result.source);
      showToast(`Published ${count} regulatory policies to Cloud Firestore.`);
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Unable to write policies to Firestore.');
    } finally {
      setIsSeeding(false);
    }
  }

  async function handleSaveAlertRule(rule: AlertRule) {
    const updated = [rule, ...alertRules];
    setAlertRules(updated);
    localStorage.setItem(LOCAL_ALERTS_KEY, JSON.stringify(updated));
    if (user && user.emailVerified) {
      try {
        await saveUserAlertRule(user.uid, rule);
        showToast('Alert rule saved to Cloud Firestore.');
      } catch {
        showToast('Saved locally; Firestore permission check failed.');
      }
    } else {
      showToast('Alert rule saved locally.');
    }
  }

  async function handleDeleteAlertRule(ruleId: string) {
    const updated = alertRules.filter((r) => r.id !== ruleId);
    setAlertRules(updated);
    localStorage.setItem(LOCAL_ALERTS_KEY, JSON.stringify(updated));
    if (user && user.emailVerified) {
      try {
        await removeUserAlertRule(ruleId);
      } catch {
        // ignore if local-only
      }
    }
    showToast('Alert rule removed.');
  }

  async function handleToggleAlertRule(rule: AlertRule) {
    const nextRule = { ...rule, enabled: !rule.enabled };
    const updated = alertRules.map((r) => (r.id === rule.id ? nextRule : r));
    setAlertRules(updated);
    localStorage.setItem(LOCAL_ALERTS_KEY, JSON.stringify(updated));
    if (user && user.emailVerified) {
      try {
        await saveUserAlertRule(user.uid, nextRule);
      } catch {
        // ignore if local-only
      }
    }
  }

  async function handleAuthClick() {
    if (user) {
      await signOutUser();
      showToast('Signed out.');
    } else {
      try {
        const loggedIn = await signInWithGoogle();
        showToast(`Signed in as ${loggedIn.email}`);
      } catch (err: unknown) {
        showToast(err instanceof Error ? err.message : 'Google sign-in cancelled.');
      }
    }
  }

  const isAdminUser = Boolean(
    user && user.emailVerified && user.email === 'projectwolverst@gmail.com'
  );

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900 dark:bg-obsidian-950 dark:text-slate-100">
      {/* Strict 3-Zone Top Bar Contract */}
      <header className="sticky top-0 z-30 bg-white/95 dark:bg-obsidian-950/95 backdrop-blur-sm border-b border-slate-200 dark:border-slate-800">
        <div className="max-w-[1400px] mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-8">
          {/* Zone 1: Single-line Brand Wordmark */}
          <button
            type="button"
            onClick={() => setActiveView('feed')}
            className="text-lg font-bold tracking-tight text-slate-900 dark:text-white whitespace-nowrap shrink-0 cursor-pointer"
          >
            wolfreg
          </button>

          {/* Zone 2: 4 Clean Single-Line Nav Links */}
          <nav className="hidden md:flex items-center gap-6 text-sm font-medium">
            {(
              [
                ['feed', 'Policy Feed'],
                ['diffs', 'Amendment Diffs'],
                ['portals', 'Govt Portals'],
                ['memo', 'Boardroom Memo'],
              ] as [WorkspaceView, string][]
            ).map(([viewKey, label]) => {
              const active = activeView === viewKey;
              return (
                <button
                  key={viewKey}
                  type="button"
                  onClick={() => setActiveView(viewKey)}
                  className={`py-1 whitespace-nowrap shrink-0 border-b-2 transition-colors cursor-pointer ${
                    active
                      ? 'border-emerald-500 text-slate-900 dark:text-white'
                      : 'border-transparent text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  {label}
                </button>
              );
            })}
          </nav>

          {/* Zone 3: 1 Primary CTA */}
          <div className="flex items-center shrink-0">
            <button
              type="button"
              onClick={() => {
                setFocusedPolicy(null);
                setAnalystOpen(true);
              }}
              className="px-4 py-2 text-xs font-semibold rounded-lg bg-slate-900 text-white dark:bg-emerald-500 dark:text-obsidian-950 hover:bg-slate-800 dark:hover:bg-emerald-400 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Ask wolfreg Analyst
            </button>
          </div>
        </div>

        {/* Mobile Navigation Strip */}
        <div className="md:hidden border-t border-slate-200 dark:border-slate-800 px-4 py-2 flex items-center gap-4 overflow-x-auto text-xs font-medium">
          {(
            [
              ['feed', 'Policy Feed'],
              ['diffs', 'Amendment Diffs'],
              ['portals', 'Govt Portals'],
              ['memo', 'Boardroom Memo'],
            ] as [WorkspaceView, string][]
          ).map(([viewKey, label]) => (
            <button
              key={viewKey}
              type="button"
              onClick={() => setActiveView(viewKey)}
              className={`whitespace-nowrap shrink-0 py-1 ${
                activeView === viewKey
                  ? 'text-emerald-600 dark:text-emerald-400 font-semibold'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              {label}
            </button>
          ))}
        </div>
      </header>

      {/* Main Executive Workspace */}
      <main className="flex-1 max-w-[1400px] w-full mx-auto px-4 sm:px-6 py-6 space-y-6">
        {/* Workspace Control Bar: Ask wolfreg Search + Persona Selector + Utility Actions */}
        <section className="bg-white dark:bg-obsidian-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 space-y-4">
          <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-3">
            {/* Ask wolfreg AI Analyst Bar */}
            <form onSubmit={handleAnalystBarSubmit} className="flex-1 flex items-center gap-2">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="text"
                  value={analystSearchInput}
                  onChange={(e) => setAnalystSearchInput(e.target.value)}
                  placeholder="Ask wolfreg AI Analyst across MNRE, CERC, SECI, IREDA, MoP, CEA, PIB & e-Gazette..."
                  className="w-full pl-10 pr-4 py-2 text-sm bg-slate-50 dark:bg-obsidian-850 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500/40"
                />
              </div>
              <button
                type="submit"
                className="px-4 py-2 text-xs font-semibold rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-obsidian-850 text-slate-800 dark:text-slate-100 hover:bg-slate-50 dark:hover:bg-obsidian-800 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                Query AI
              </button>
            </form>

            {/* Persona Selector + Utilities */}
            <div className="flex flex-wrap items-center gap-2.5 shrink-0">
              <div className="flex items-center gap-2">
                <label
                  htmlFor="persona-select"
                  className="text-xs font-medium text-slate-500 dark:text-slate-400 whitespace-nowrap"
                >
                  Perspective
                </label>
                <select
                  id="persona-select"
                  value={personaId}
                  onChange={(e) => setPersonaId(e.target.value as PersonaId)}
                  className="px-3 py-2 text-xs font-semibold bg-slate-50 dark:bg-obsidian-850 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/40 cursor-pointer"
                >
                  {PERSONAS.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.label}
                    </option>
                  ))}
                </select>
              </div>

              <button
                type="button"
                onClick={() => setAlertModalOpen(true)}
                className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-obsidian-850 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Bell className="w-3.5 h-3.5 text-amber-600 dark:text-gold-400" />
                Alerts ({alertRules.filter((r) => r.enabled).length})
              </button>

              <button
                type="button"
                onClick={handleCopy60SecondDigest}
                className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-obsidian-850 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                {digestCopied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-500" />
                    Copied Digest
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    60s Digest
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={handleToggleTheme}
                aria-label={isDark ? 'Switch to light mode' : 'Switch to dark mode'}
                className="p-2 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-obsidian-850 transition-colors cursor-pointer shrink-0"
              >
                {isDark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
              </button>

              <button
                type="button"
                onClick={handleAuthClick}
                className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-obsidian-850 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                {user ? (
                  <>
                    <LogOut className="w-3.5 h-3.5" />
                    <span className="max-w-[110px] truncate">{user.email}</span>
                  </>
                ) : (
                  <>
                    <LogIn className="w-3.5 h-3.5" />
                    Sign In
                  </>
                )}
              </button>
            </div>
          </div>

          {/* 4-Column Flat KPI Summary Strip */}
          <div className="grid grid-cols-2 lg:grid-cols-4 divide-y lg:divide-y-0 lg:divide-x divide-slate-200 dark:divide-slate-800 border-t border-slate-200 dark:border-slate-800 pt-3">
            <div className="py-1.5 lg:pr-4">
              <div className="text-xs text-slate-500 dark:text-slate-400">Active Policy Corpus</div>
              <div className="text-lg font-semibold font-mono tabular-nums text-slate-900 dark:text-white mt-0.5">
                {policies.length} Orders
              </div>
            </div>
            <div className="py-1.5 lg:px-4">
              <div className="text-xs text-slate-500 dark:text-slate-400">
                High Impact (85%+ · {activePersona.shortLabel})
              </div>
              <div className="text-lg font-semibold font-mono tabular-nums text-emerald-600 dark:text-emerald-500 mt-0.5">
                {highImpactCount} Notifications
              </div>
            </div>
            <div className="py-1.5 lg:px-4">
              <div className="text-xs text-slate-500 dark:text-slate-400">Critical Statutory Shifts</div>
              <div className="text-lg font-semibold font-mono tabular-nums text-amber-600 dark:text-gold-400 mt-0.5">
                {criticalCount} Mandates
              </div>
            </div>
            <div className="py-1.5 lg:pl-4">
              <div className="text-xs text-slate-500 dark:text-slate-400">Firestore Connection</div>
              <div className="text-sm font-semibold text-slate-900 dark:text-white mt-1">
                {dataSource === 'firestore' ? 'Cloud Firestore Live' : 'Benchmark Cache Active'}
              </div>
            </div>
          </div>
        </section>

        {/* Active View Viewport */}
        {activeView === 'feed' && (
          <section className="space-y-4">
            {/* Filter Controls Bar */}
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
              {/* Source Portals Segmented Filter */}
              <div className="flex items-center gap-1 p-1 bg-white dark:bg-obsidian-900 border border-slate-200 dark:border-slate-800 rounded-lg overflow-x-auto">
                {AGENCIES.map((agency) => (
                  <button
                    key={agency}
                    type="button"
                    onClick={() => setAgencyFilter(agency)}
                    className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                      agencyFilter === agency
                        ? 'bg-slate-900 text-white dark:bg-obsidian-800 dark:text-white'
                        : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                    }`}
                  >
                    {agency}
                  </button>
                ))}
              </div>

              {/* Sector + 85%+ Threshold + Keyword Filter */}
              <div className="flex flex-wrap items-center gap-2.5">
                <input
                  type="text"
                  value={feedQuery}
                  onChange={(e) => setFeedQuery(e.target.value)}
                  placeholder="Filter dockets or titles..."
                  className="px-3 py-1.5 text-xs bg-white dark:bg-obsidian-900 border border-slate-200 dark:border-slate-800 rounded-lg text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500/40"
                />

                <select
                  aria-label="Filter by sector"
                  value={sectorFilter}
                  onChange={(e) => setSectorFilter(e.target.value as 'All' | Sector)}
                  className="px-3 py-1.5 text-xs font-medium bg-white dark:bg-obsidian-900 border border-slate-200 dark:border-slate-800 rounded-lg text-slate-800 dark:text-slate-200 cursor-pointer"
                >
                  {SECTORS.map((s) => (
                    <option key={s} value={s}>
                      {s === 'All' ? 'All Sectors' : s}
                    </option>
                  ))}
                </select>

                <button
                  type="button"
                  onClick={() => setHighImpactOnly((prev) => !prev)}
                  className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    highImpactOnly
                      ? 'bg-emerald-500/15 border-emerald-500/60 text-emerald-700 dark:text-emerald-400'
                      : 'bg-white dark:bg-obsidian-900 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300'
                  }`}
                >
                  <SlidersHorizontal className="w-3.5 h-3.5" />
                  85%+ High Impact
                </button>
              </div>
            </div>

            {/* Policy Feed Cards */}
            {isLoadingPolicies ? (
              <div className="space-y-4">
                {[1, 2, 3].map((idx) => (
                  <div
                    key={idx}
                    className="h-44 bg-white dark:bg-obsidian-900 border border-slate-200 dark:border-slate-800 rounded-xl animate-pulse"
                  />
                ))}
              </div>
            ) : filteredPolicies.length === 0 ? (
              <div className="bg-white dark:bg-obsidian-900 border border-slate-200 dark:border-slate-800 rounded-xl p-12 text-center">
                <p className="text-sm text-slate-600 dark:text-slate-400 mb-3">
                  No regulatory notifications match your current portal, sector, or 85%+ impact filters.
                </p>
                <button
                  type="button"
                  onClick={() => {
                    setAgencyFilter('All');
                    setSectorFilter('All');
                    setHighImpactOnly(false);
                    setFeedQuery('');
                  }}
                  className="px-4 py-2 text-xs font-semibold rounded-lg bg-slate-900 text-white dark:bg-emerald-500 dark:text-obsidian-950 cursor-pointer"
                >
                  Reset Feed Filters
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                {filteredPolicies.map((policy) => (
                  <PolicyCard
                    key={policy.id}
                    policy={policy}
                    persona={activePersona}
                    isPinned={pinnedPolicyIds.includes(policy.id)}
                    onTogglePin={handleTogglePin}
                    onAskAnalyst={handleAskPolicyAnalyst}
                  />
                ))}
              </div>
            )}
          </section>
        )}

        {activeView === 'diffs' && (
          <AmendmentDiffView
            policies={policies}
            persona={activePersona}
            onAskAnalyst={handleAskPolicyAnalyst}
          />
        )}

        {activeView === 'portals' && (
          <PortalsHubView
            portals={portals}
            syncingAgency={syncingAgency}
            dataSource={dataSource}
            isAdminUser={isAdminUser}
            isSeeding={isSeeding}
            onSyncPortal={handleSyncPortal}
            onSyncAll={handleSyncAllPortals}
            onSeedFirestore={handleSeedFirestore}
            onFilterByAgency={(agency) => {
              setAgencyFilter(agency);
              setActiveView('feed');
            }}
          />
        )}

        {activeView === 'memo' && (
          <BoardroomMemoView
            policies={policies}
            pinnedPolicyIds={pinnedPolicyIds}
            persona={activePersona}
            onTogglePin={handleTogglePin}
          />
        )}
      </main>

      {/* Quiet Institutional Footer */}
      <footer className="border-t border-slate-200 dark:border-slate-800 mt-10">
        <div className="max-w-[1400px] mx-auto px-4 sm:px-6 py-5 flex flex-wrap items-center justify-between gap-4 text-xs text-slate-500 dark:text-slate-400">
          <span>wolfreg — Indian Renewable Energy & Climate Policy Intelligence</span>
          <span>
            Monitored Authorities: MNRE · CERC · SECI · IREDA · MoP · CEA · PIB · e-Gazette
          </span>
        </div>
      </footer>

      {/* Slide-Over Gemini Analyst Drawer */}
      <AnalystDrawer
        isOpen={analystOpen}
        onClose={() => setAnalystOpen(false)}
        persona={activePersona}
        policies={policies}
        focusedPolicy={focusedPolicy}
        initialPrompt={analystInitialPrompt}
        onClearInitialPrompt={() => setAnalystInitialPrompt(null)}
      />

      {/* Smart Executive Alert Modal */}
      <SmartAlertModal
        isOpen={alertModalOpen}
        onClose={() => setAlertModalOpen(false)}
        persona={activePersona}
        policies={policies}
        rules={alertRules}
        isSignedIn={Boolean(user && user.emailVerified)}
        onSaveRule={handleSaveAlertRule}
        onDeleteRule={handleDeleteAlertRule}
        onToggleRule={handleToggleAlertRule}
      />

      {/* Ephemeral Toast Notification */}
      {toastMessage && (
        <div
          role="status"
          className="fixed bottom-5 right-5 z-50 px-4 py-2.5 rounded-lg bg-slate-900 text-white dark:bg-obsidian-800 border border-slate-700 text-xs font-medium shadow-xl"
        >
          {toastMessage}
        </div>
      )}
    </div>
  );
}
