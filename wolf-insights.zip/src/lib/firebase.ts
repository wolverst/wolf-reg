import { initializeApp, getApps } from 'firebase/app';
import {
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
  signOut,
  User,
} from 'firebase/auth';
import {
  collection,
  deleteDoc,
  doc,
  getDocFromServer,
  getDocs,
  getFirestore,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
  where,
} from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';
import { SAMPLE_POLICIES } from '../data/policies';
import { AlertRule, PolicyDocument } from '../types';

const app = getApps().length ? getApps()[0] : initializeApp(firebaseConfig);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth(app);
const googleProvider = new GoogleAuthProvider();

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null
): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid ?? null,
      email: auth.currentUser?.email ?? null,
      emailVerified: auth.currentUser?.emailVerified ?? null,
      isAnonymous: auth.currentUser?.isAnonymous ?? null,
      tenantId: auth.currentUser?.tenantId ?? null,
      providerInfo:
        auth.currentUser?.providerData?.map((provider) => ({
          providerId: provider.providerId,
          email: provider.email,
        })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

export async function testFirestoreConnection(): Promise<boolean> {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    return true;
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.error('Please check your Firebase configuration. Client appears offline.');
      return false;
    }
    return true;
  }
}

export async function signInWithGoogle(): Promise<User> {
  const result = await signInWithPopup(auth, googleProvider);
  return result.user;
}

export async function signOutUser(): Promise<void> {
  await signOut(auth);
}

export async function fetchPoliciesWithFallback(): Promise<{
  policies: PolicyDocument[];
  source: 'firestore' | 'fallback';
  note?: string;
}> {
  const path = 'policies';
  try {
    const q = query(collection(db, path), where('isPublished', '==', true));
    const snapshot = await getDocs(q);

    if (snapshot.empty) {
      return {
        policies: SAMPLE_POLICIES,
        source: 'fallback',
        note: 'Firestore policies collection is empty — displaying 8 verified Indian policy benchmarks.',
      };
    }

    const docs: PolicyDocument[] = snapshot.docs.map((d) => {
      const data = d.data() as PolicyDocument;
      return {
        ...data,
        id: data.id || d.id,
      };
    });

    docs.sort((a, b) => b.publishedDate.localeCompare(a.publishedDate));
    return { policies: docs, source: 'firestore' };
  } catch (error) {
    const msg = error instanceof Error ? error.message : String(error);
    if (msg.toLowerCase().includes('permission') || msg.toLowerCase().includes('insufficient')) {
      try {
        handleFirestoreError(error, OperationType.LIST, path);
      } catch {
        // Fallback gracefully after structured logging
      }
    }
    return {
      policies: SAMPLE_POLICIES,
      source: 'fallback',
      note: 'Offline or unseeded Firestore — displaying 8 verified Indian policy benchmarks.',
    };
  }
}

export async function seedSamplePoliciesToFirestore(): Promise<number> {
  let count = 0;
  for (const policy of SAMPLE_POLICIES) {
    const path = `policies/${policy.id}`;
    try {
      await setDoc(doc(db, 'policies', policy.id), {
        ...policy,
        createdAt: serverTimestamp(),
      });
      count += 1;
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
  }
  return count;
}

export async function fetchUserAlertRules(uid: string): Promise<AlertRule[]> {
  const path = 'alertRules';
  try {
    const q = query(
      collection(db, path),
      where('ownerId', '==', uid),
      orderBy('createdAt', 'desc')
    );
    const snap = await getDocs(q);
    return snap.docs.map((d) => {
      const data = d.data();
      return {
        id: d.id,
        channel: data.channel,
        destination: data.destination,
        minRelevanceScore: data.minRelevanceScore,
        personaId: data.personaId,
        cadence: data.cadence,
        sectors: data.sectors || [],
        enabled: Boolean(data.enabled),
      } as AlertRule;
    });
  } catch (error) {
    const msg = error instanceof Error ? error.message : String(error);
    if (msg.toLowerCase().includes('permission')) {
      handleFirestoreError(error, OperationType.LIST, path);
    }
    return [];
  }
}

export async function saveUserAlertRule(uid: string, rule: AlertRule): Promise<void> {
  const path = `alertRules/${rule.id}`;
  try {
    await setDoc(doc(db, 'alertRules', rule.id), {
      ownerId: uid,
      channel: rule.channel,
      destination: rule.destination.slice(0, 160),
      minRelevanceScore: Math.max(50, Math.min(100, Math.round(rule.minRelevanceScore))),
      personaId: rule.personaId,
      cadence: rule.cadence,
      sectors: rule.sectors.slice(0, 6),
      enabled: rule.enabled,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function removeUserAlertRule(ruleId: string): Promise<void> {
  const path = `alertRules/${ruleId}`;
  try {
    await deleteDoc(doc(db, 'alertRules', ruleId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}
