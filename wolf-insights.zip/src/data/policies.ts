import { PersonaConfig, PolicyDocument, PortalStatus } from '../types';

export const PERSONAS: PersonaConfig[] = [
  {
    id: 'investor',
    label: 'Investor / Family Office',
    shortLabel: 'Investor',
    mandate: 'Capital deployment, project IRR sensitivity, VGF & ISTS tariff bankability, and stranded asset risk.',
    focusMetrics: 'Equity IRR · Offtake Bankability · Subsidy Uplift',
  },
  {
    id: 'startup',
    label: 'Renewable Energy Startup',
    shortLabel: 'RE Startup',
    mandate: 'Tender market entry, green-shoe capacity windows, C&I open-access arbitrage, and OEM/EPC margins.',
    focusMetrics: 'Bid Eligibility · Working Capital · Margin Arbitrage',
  },
  {
    id: 'biogas',
    label: 'Biogas Plant Operator',
    shortLabel: 'Biogas / CBG',
    mandate: 'Mandatory CBG blending (CBO), SATAT 2.0 biomass logistics subsidies, and concessional IREDA debt.',
    focusMetrics: 'CBO Price Floor · Feedstock Subsidy · Debt Subvention',
  },
  {
    id: 'climatetech',
    label: 'Climate Tech Companies',
    shortLabel: 'Climate Tech',
    mandate: 'Grid-forming BESS telemetry software, domestic solar cell supply-chain tech, electrolyzers, and carbon registries.',
    focusMetrics: 'EMS Compliance · Hardware Localization · Registry API',
  },
];

export const SAMPLE_POLICIES: PolicyDocument[] = [
  {
    id: 'mnre-almm-cell-mandate-2026',
    docketNumber: 'OM No. 283/54/2018-GRID SOLAR-Pt(4)',
    agency: 'MNRE',
    sector: 'Solar',
    title: 'ALMM List-II Mandate for Domestic Solar PV Cells & Utility Tender Applicability',
    publishedDate: '2026-11-11',
    effectiveDate: '01 Jun 2026',
    severity: 'Critical',
    aiSummary:
      'MNRE mandates that all grid-connected solar PV projects bid under central/state agencies and open-access C&I portfolios must source modules exclusively from ALMM List-I built using domestic solar cells listed in ALMM List-II.',
    amendmentClause: 'Clause 3.2 — Domestic Cell Content Requirement',
    supersededRule:
      'ALMM List-I applied solely to finished PV module assembly; developers could import Tier-1 TOPCon or Mono-PERC wafers and cells without domestic cell sourcing mandates.',
    newRule:
      'Projects with bid submission post notification must procure modules manufactured with ALMM List-II enlisted Indian solar PV cells, eliminating imported cell exemptions except for legacy pre-cut-off PPAs.',
    sourceUrl: 'https://mnre.gov.in/almm-list-ii-notification',
    isPublished: true,
    personaProfiles: {
      investor: {
        relevanceScore: 95,
        impactSummary:
          'Raises utility solar module capex by ₹2.8–3.4 Cr/MW in the near term; prioritize IPPs with backward-integrated domestic TOPCon cell pipelines.',
      },
      startup: {
        relevanceScore: 92,
        impactSummary:
          'Creates immediate procurement bottleneck for C&I EPCs; lock in domestic cell allocations or pivot bids toward BESS-hybrid packages.',
      },
      biogas: {
        relevanceScore: 34,
        impactSummary:
          'Minimal direct exposure unless co-locating captive rooftop solar (>1 MW) for CBG compressor parasitic load.',
      },
      climatetech: {
        relevanceScore: 89,
        impactSummary:
          'Accelerates demand for domestic wafer-to-cell yield analytics, defect-vision QA systems, and module traceability software.',
      },
    },
  },
  {
    id: 'cerc-gna-2nd-amendment-2026',
    docketNumber: 'No. L-1/261/2021/CERC (2nd Amend.)',
    agency: 'CERC',
    sector: 'Grid & BESS',
    title: 'Connectivity & General Network Access (GNA) 2nd Amendment: BESS Co-Location & BG2 Norms',
    publishedDate: '2026-11-09',
    effectiveDate: '01 Dec 2026',
    severity: 'Critical',
    aiSummary:
      'CERC permits solar/wind generators to share existing ISTS GNA bays with co-located standalone BESS without fresh connectivity fees, while tightening Bank Guarantee (BG2) forfeiture triggers for delayed financial closure.',
    amendmentClause: 'Regulation 11A & 16.4 — Shared Bay Access & BG Encashment',
    supersededRule:
      'Co-located storage additions at an existing RE pooling substation required a separate GNA connectivity application and incremental ₹50 Lakh/MW transmission bank guarantee.',
    newRule:
      'Existing connectivity grantees may integrate up to 100% rated BESS capacity within sanctioned injection limits via a 30-day CTUIL technical addendum; however, 6-month financial closure slippage triggers 50% BG2 encashment.',
    sourceUrl: 'https://cercind.gov.in/regulations-gna-amendment',
    isPublished: true,
    personaProfiles: {
      investor: {
        relevanceScore: 97,
        impactSummary:
          'Unlocks 180–240 bps IRR uplift on brownfield ISTS sites by retrofitting BESS for peak merchant arbitrage without waiting in 24-month CTUIL queues.',
      },
      startup: {
        relevanceScore: 88,
        impactSummary:
          'Watch out for stricter 6-month BG2 financial closure clocks—underfunded SPVs face immediate ₹50L/MW collateral forfeiture.',
      },
      biogas: {
        relevanceScore: 42,
        impactSummary:
          'Indirectly relevant only for large bio-power cogeneration plants exporting >50 MW into ISTS substations.',
      },
      climatetech: {
        relevanceScore: 91,
        impactSummary:
          'Massive B2B opening for automated substation dispatch controllers managing hybrid RE + BESS injection ceilings under CTUIL SCADA rules.',
      },
    },
  },
  {
    id: 'seci-fdre-iv-rtc-guidelines-2026',
    docketNumber: 'SECI/C&P/IPP/FDRE-IV/2026/089',
    agency: 'SECI',
    sector: 'Grid & BESS',
    title: 'FDRE-IV Firm & Dispatchable Renewable Energy Tender: Evening Peak & Green-Shoe Revision',
    publishedDate: '2026-11-06',
    effectiveDate: 'Immediate (Tranche IV)',
    severity: 'Material',
    aiSummary:
      'SECI raises mandatory evening peak availability (18:00–23:00 IST) from 85% to 90% in FDRE-IV tenders while introducing a 100% Green-Shoe allocation option for lowest-discovered tariff bidders.',
    amendmentClause: 'RfS Section 4.4.2 — Peak Availability Penalty & Green-Shoe',
    supersededRule:
      'FDRE-II/III tenders mandated 85% monthly availability during peak hours with a 1.5x tariff penalty and capped green-shoe expansion at 50% of quoted capacity.',
    newRule:
      'Bidders must guarantee 90% availability across 4 peak evening hours with 2.0x liquidated damages for shortfall, alongside an optional 100% Green-Shoe capacity award at L1 tariff.',
    sourceUrl: 'https://seci.co.in/tenders/fdre-iv-2026',
    isPublished: true,
    personaProfiles: {
      investor: {
        relevanceScore: 93,
        impactSummary:
          'Favors well-capitalized platforms with 4-hour LFP battery supply agreements; 2.0x shortfall penalty penalizes undersized storage sizing.',
      },
      startup: {
        relevanceScore: 86,
        impactSummary:
          '100% Green-Shoe allows agile consortiums to double contracted GW scale post-eRA, though minimum net-worth thresholds remain ₹1.2 Cr/MW.',
      },
      biogas: {
        relevanceScore: 51,
        impactSummary:
          'Opens minor firming-power partnership angles if bio-CNG/biogas CHP units qualify as dispatchable renewable firming capacity.',
      },
      climatetech: {
        relevanceScore: 90,
        impactSummary:
          'Requires AI-driven day-ahead weather + battery state-of-charge optimization to defend the tighter 90% peak availability SLA.',
      },
    },
  },
  {
    id: 'ireda-cbg-gh2-debt-subvention-2026',
    docketNumber: 'IREDA/FIN/CIR/2026-142',
    agency: 'IREDA',
    sector: 'Biogas & CBG',
    title: 'Concessional Term Debt Facility for >10 TPD CBG Plants & SIGHT Tranche-II Electrolyzers',
    publishedDate: '2026-11-04',
    effectiveDate: '15 Nov 2026',
    severity: 'Critical',
    aiSummary:
      'IREDA launches a dedicated ₹6,500 Cr lending window offering a 75 bps interest rate subvention and 15-year door-to-door tenure for commercial CBG facilities and domestic electrolyzer manufacturing units.',
    amendmentClause: 'Lending Policy Schedule B — Priority Clean Fuel Spreads',
    supersededRule:
      'CBG projects were priced at standard RE project-finance spreads (10.25%–11.10% p.a.) with 10-year repayment caps and 30% promoter equity requirements.',
    newRule:
      'Projects with confirmed OMC offtake or CBO certificate registration receive 75 bps rate reduction (effective ~9.40% p.a.), 15-year tenure, and 75:25 debt-to-equity leverage.',
    sourceUrl: 'https://ireda.in/circulars/cbg-gh2-2026',
    isPublished: true,
    personaProfiles: {
      investor: {
        relevanceScore: 90,
        impactSummary:
          '75:25 leverage plus 75 bps spread compression lifts CBG equity IRR by ~290 bps, making mid-market bioenergy roll-ups bankable.',
      },
      startup: {
        relevanceScore: 87,
        impactSummary:
          'Reduces promoter equity lock-up by 5 percentage points for emerging CBG and electrolyzer OEM ventures.',
      },
      biogas: {
        relevanceScore: 98,
        impactSummary:
          'Direct balance-sheet catalyst: refinance existing 11%+ term loans or fund new >10 TPD paddy-straw/pressmud CBG plants at 9.4% over 15 years.',
      },
      climatetech: {
        relevanceScore: 82,
        impactSummary:
          'Qualifies domestic PEM/Alkaline electrolyzer balance-of-plant component startups for priority capex debt.',
      },
    },
  },
  {
    id: 'mop-ists-waiver-gh2-psp-2026',
    docketNumber: 'No. 23/12/2016-R&R (Vol-VI)',
    agency: 'MoP',
    sector: 'Green Hydrogen',
    title: 'ISTS Transmission Charge Waiver Framework: Solar/Wind Step-Down vs. Green Hydrogen & PSP Carve-Out',
    publishedDate: '2026-10-30',
    effectiveDate: '01 Jul 2026',
    severity: 'Critical',
    aiSummary:
      'Ministry of Power confirms the phased 25% annual step-down of ISTS charge waivers for plain solar/wind plants commissioned post-June 2025, while preserving a 100% 25-year waiver for Green Hydrogen/Ammonia and Pumped Hydro Storage until Dec 2030.',
    amendmentClause: 'Para 3.1(ii) — Extended ISTS Waiver Carve-Out',
    supersededRule:
      'Blanket 100% ISTS waiver applied across utility solar, wind, BESS, and Green Hydrogen projects commissioned before June 2025, with ambiguity on hybrid electrolyzer captive wheeling.',
    newRule:
      'Plain solar/wind faces 50% ISTS charges from July 2026; however, dedicated RE supplying Green Hydrogen/Ammonia plants or co-located PSP retains 100% ISTS waiver for 25 years if commissioned by Dec 2030.',
    sourceUrl: 'https://powermin.gov.in/ists-waiver-order-2026',
    isPublished: true,
    personaProfiles: {
      investor: {
        relevanceScore: 96,
        impactSummary:
          'Protects interstate Rajasthan/Gujarat RE wheeling economics exclusively for Green Ammonia & PSP portfolios—avoid unhedged plain-solar ISTS merchant exposure.',
      },
      startup: {
        relevanceScore: 81,
        impactSummary:
          'Shifts C&I open-access developers toward intra-state STU sites for standard solar while concentrating ISTS expansion around Green Hydrogen hubs.',
      },
      biogas: {
        relevanceScore: 38,
        impactSummary:
          'Low direct impact unless operating bio-hydrogen reformation integrated with interstate green power wheeling.',
      },
      climatetech: {
        relevanceScore: 88,
        impactSummary:
          'Reinforces coastal port-linked Green Ammonia clusters (Kandla, Paradip, Tuticorin) procuring cheap Rajasthan solar via zero-cost ISTS wheeling.',
      },
    },
  },
  {
    id: 'cea-grid-forming-bess-standards-2026',
    docketNumber: 'CEA/TETD/GRID-STD/2026/19',
    agency: 'CEA',
    sector: 'Grid & BESS',
    title: 'Technical Standards for Connectivity: Grid-Forming Inverters & 1-Second Telemetry for BESS',
    publishedDate: '2026-10-27',
    effectiveDate: '01 Apr 2027',
    severity: 'Material',
    aiSummary:
      'CEA mandates grid-forming (GFM) inverter capability with synthetic inertia and 1-second PMU/SCADA telemetry streaming to RLDCs for all standalone BESS and ≥50 MW inverter-based renewable plants.',
    amendmentClause: 'Schedule IV Part B2 — Inverter Synthetic Inertia & Telemetry',
    supersededRule:
      'Grid-following (GFL) inverters with basic LVRT/HVRT and 5-minute SCADA polling satisfied CEA connectivity norms for utility solar and wind plants.',
    newRule:
      'All newly commissioned ≥50 MW IBRs and BESS installations must deploy certified Grid-Forming firmware capable of black-start/synthetic inertia and continuous 1-second RLDC telemetry.',
    sourceUrl: 'https://cea.nic.in/grid-connectivity-amendment-2026',
    isPublished: true,
    personaProfiles: {
      investor: {
        relevanceScore: 79,
        impactSummary:
          'Adds ~1.8% to inverter/PCS hardware cost; verify EPC vendor GFM certification to prevent RLDC COD commissioning delays.',
      },
      startup: {
        relevanceScore: 84,
        impactSummary:
          'Creates vendor lock-in risk for low-cost inverter imports; local EMS integrators with compliant RLDC telemetry stacks gain tender edge.',
      },
      biogas: {
        relevanceScore: 29,
        impactSummary:
          'Synchronous biogas gensets are naturally grid-forming and exempt from inverter-specific firmware retrofits.',
      },
      climatetech: {
        relevanceScore: 96,
        impactSummary:
          'High-conviction tailwind for power-electronics startups, GFM control firmware vendors, and high-frequency PMU grid-telemetry SaaS.',
      },
    },
  },
  {
    id: 'pib-vgf-bess-satat2-cabinet-2026',
    docketNumber: 'PIB/PRID-2098412 (Cabinet Note)',
    agency: 'PIB',
    sector: 'Biogas & CBG',
    title: 'Cabinet Clears ₹3,760 Cr Phase-II BESS VGF Tranche & SATAT 2.0 Biomass Aggregation Subsidy',
    publishedDate: '2026-10-24',
    effectiveDate: 'FY 2026-27',
    severity: 'Critical',
    aiSummary:
      'Union Cabinet approves an additional 4,000 MWh Viability Gap Funding (up to 35% capex) for grid BESS and introduces a ₹1,450/tonne paddy-straw & biomass baling subsidy under SATAT 2.0 across northern agrarian belts.',
    amendmentClause: 'Cabinet Scheme — SATAT 2.0 Feedstock & BESS VGF',
    supersededRule:
      'Previous BESS VGF capped at 40% for initial 4,000 MWh with no dedicated biomass baling/storage reimbursement for independent CBG feedstock aggregators.',
    newRule:
      'Unlocks ₹3,760 Cr Phase-II BESS VGF disbursed in 3 COD-linked tranches plus direct ₹1,450/tonne DBT logistics support for CBG feedstock aggregation machinery.',
    sourceUrl: 'https://pib.gov.in/PressReleaseDetail.aspx?PRID=2098412',
    isPublished: true,
    personaProfiles: {
      investor: {
        relevanceScore: 94,
        impactSummary:
          'De-risks both utility storage capex (35% non-dilutive grant) and CBG working capital volatility caused by seasonal stubble price spikes.',
      },
      startup: {
        relevanceScore: 89,
        impactSummary:
          'Unlocks agri-supply-chain fintech and baler-fleet SaaS partnerships across Punjab, Haryana, and western UP.',
      },
      biogas: {
        relevanceScore: 99,
        impactSummary:
          'Directly lowers paddy-straw landed feedstock cost by ~₹1,450/tonne, expanding CBG EBITDA margins by 450–600 bps.',
      },
      climatetech: {
        relevanceScore: 85,
        impactSummary:
          'Mandates geo-tagged biomass procurement verification and digital weighbridge audit trails to claim SATAT 2.0 subsidies.',
      },
    },
  },
  {
    id: 'egazette-cbo-mandatory-blending-2026',
    docketNumber: 'G.S.R. 612(E) — Gazette Extraordinary',
    agency: 'e-Gazette',
    sector: 'Biogas & CBG',
    title: 'Mandatory CBG Blending Obligation (CBO) & Tradable Green Gas Certificate Rules',
    publishedDate: '2026-10-19',
    effectiveDate: '01 Apr 2026',
    severity: 'Critical',
    aiSummary:
      'Statutory Gazette notification enforces a binding 5% Compressed Biogas Blending Obligation (CBO) on all City Gas Distribution (CGD) entities for CNG/PNG sales, backed by tradable Green Gas Certificates and non-compliance penalties.',
    amendmentClause: 'Rule 5(2) — Statutory Blending Trajectory & Penalties',
    supersededRule:
      'CBG blending under the initial 2023 MoPNG roadmap operated on voluntary targets (1%–3%) without statutory penalty enforcement or tradable certificate clearing.',
    newRule:
      'Enforces mandatory 3% blending in FY26 escalating to 5% in FY27 across all CGD networks; shortfalls incur ₹1,200/MMBtu penalty unless offset via registered Green Gas Certificates.',
    sourceUrl: 'https://egazette.gov.in/WriteReadData/2026/612E.pdf',
    isPublished: true,
    personaProfiles: {
      investor: {
        relevanceScore: 92,
        impactSummary:
          'Transforms Indian CBG from policy-dependent to legally mandated demand; Green Gas Certificates create a secondary yield stream.',
      },
      startup: {
        relevanceScore: 83,
        impactSummary:
          'Creates immediate market for CBG-to-CGD pipeline injection skids, gas-quality analyzers, and certificate trading platforms.',
      },
      biogas: {
        relevanceScore: 100,
        impactSummary:
          'Guarantees long-term CGD offtake demand and establishes a statutory ₹1,200/MMBtu penalty floor protecting CBG realizations.',
      },
      climatetech: {
        relevanceScore: 87,
        impactSummary:
          'Drives enterprise demand for MRV (Monitoring, Reporting & Verification) carbon accounting and Green Gas Certificate registry APIs.',
      },
    },
  },
];

export const INITIAL_PORTALS: PortalStatus[] = [
  {
    agency: 'MNRE',
    fullName: 'Ministry of New & Renewable Energy',
    domain: 'mnre.gov.in',
    cadence: 'Every 15 min',
    trackedDocs: 142,
    lastSyncedMinutesAgo: 4,
    status: 'Synced',
    latestDocket: 'OM No. 283/54/2018-GRID SOLAR-Pt(4)',
  },
  {
    agency: 'CERC',
    fullName: 'Central Electricity Regulatory Commission',
    domain: 'cercind.gov.in',
    cadence: 'Every 15 min',
    trackedDocs: 98,
    lastSyncedMinutesAgo: 7,
    status: 'Synced',
    latestDocket: 'No. L-1/261/2021/CERC (2nd Amend.)',
  },
  {
    agency: 'SECI',
    fullName: 'Solar Energy Corporation of India',
    domain: 'seci.co.in',
    cadence: 'Every 30 min',
    trackedDocs: 214,
    lastSyncedMinutesAgo: 11,
    status: 'Synced',
    latestDocket: 'SECI/C&P/IPP/FDRE-IV/2026/089',
  },
  {
    agency: 'IREDA',
    fullName: 'Indian Renewable Energy Dev. Agency',
    domain: 'ireda.in',
    cadence: 'Hourly',
    trackedDocs: 64,
    lastSyncedMinutesAgo: 18,
    status: 'Synced',
    latestDocket: 'IREDA/FIN/CIR/2026-142',
  },
  {
    agency: 'MoP',
    fullName: 'Ministry of Power',
    domain: 'powermin.gov.in',
    cadence: 'Every 30 min',
    trackedDocs: 119,
    lastSyncedMinutesAgo: 9,
    status: 'Synced',
    latestDocket: 'No. 23/12/2016-R&R (Vol-VI)',
  },
  {
    agency: 'CEA',
    fullName: 'Central Electricity Authority',
    domain: 'cea.nic.in',
    cadence: 'Hourly',
    trackedDocs: 87,
    lastSyncedMinutesAgo: 26,
    status: 'Synced',
    latestDocket: 'CEA/TETD/GRID-STD/2026/19',
  },
  {
    agency: 'PIB',
    fullName: 'Press Information Bureau (Energy)',
    domain: 'pib.gov.in',
    cadence: 'Every 10 min',
    trackedDocs: 305,
    lastSyncedMinutesAgo: 2,
    status: 'Synced',
    latestDocket: 'PIB/PRID-2098412',
  },
  {
    agency: 'e-Gazette',
    fullName: 'Gazette of India Extraordinary',
    domain: 'egazette.gov.in',
    cadence: 'Every 20 min',
    trackedDocs: 76,
    lastSyncedMinutesAgo: 14,
    status: 'Synced',
    latestDocket: 'G.S.R. 612(E)',
  },
];
